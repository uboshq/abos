-- MySQL dump 10.13  Distrib 8.4.3, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: abos
-- ------------------------------------------------------
-- Server version	8.4.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `parent_id` bigint unsigned DEFAULT NULL,
  `code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_bn` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nature` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_group` tinyint(1) NOT NULL DEFAULT '0',
  `is_cash` tinyint(1) NOT NULL DEFAULT '0',
  `is_bank` tinyint(1) NOT NULL DEFAULT '0',
  `is_system` tinyint(1) NOT NULL DEFAULT '0',
  `opening_balance` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `opening_date` date DEFAULT NULL,
  `account_number` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_name` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `branch_name` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'confirmed',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accounts_company_id_code_unique` (`company_id`,`code`),
  KEY `accounts_parent_id_foreign` (`parent_id`),
  KEY `accounts_created_by_foreign` (`created_by`),
  KEY `accounts_company_id_type_is_active_index` (`company_id`,`type`,`is_active`),
  KEY `accounts_company_id_parent_id_index` (`company_id`,`parent_id`),
  CONSTRAINT `accounts_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `accounts_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `accounts_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `accounts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (1,1,NULL,'1000','Assets','সম্পদ','asset','debit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(2,1,1,'1100','Current Assets','চলতি সম্পদ','asset','debit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(3,1,2,'1101','Cash in Hand','হাতে নগদ','asset','debit',1,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(4,1,2,'1102','Bank & Mobile Money','ব্যাংক ও মোবাইল ব্যাংকিং','asset','debit',1,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(5,1,2,'1110','Accounts Receivable','প্রাপ্য হিসাব','asset','debit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(6,1,2,'1120','Inventory','মজুদ পণ্য','asset','debit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(7,1,2,'1130','Advance & Prepayments','অগ্রিম ও অগ্রিম পরিশোধ','asset','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(8,1,2,'1140','Security Deposits','জামানত','asset','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(9,1,1,'1200','Fixed Assets','স্থায়ী সম্পদ','asset','debit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(10,1,9,'1201','Furniture & Fixtures','আসবাবপত্র','asset','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(11,1,9,'1202','Vehicles','যানবাহন','asset','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(12,1,9,'1203','Equipment & Machinery','যন্ত্রপাতি','asset','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(13,1,9,'1204','Computer & Accessories','কম্পিউটার ও সরঞ্জাম','asset','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(14,1,9,'1290','Accumulated Depreciation','সঞ্চিত অবচয়','asset','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(15,1,NULL,'2000','Liabilities','দায়','liability','credit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(16,1,15,'2100','Current Liabilities','চলতি দায়','liability','credit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(17,1,16,'2110','Accounts Payable','প্রদেয় হিসাব','liability','credit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(18,1,16,'2120','VAT Payable','প্রদেয় ভ্যাট','liability','credit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(19,1,16,'2130','Salary Payable','প্রদেয় বেতন','liability','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(20,1,16,'2140','Expenses Payable','প্রদেয় খরচ','liability','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(21,1,16,'2150','Advance from Customers','গ্রাহকের অগ্রিম','liability','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(22,1,15,'2200','Long Term Liabilities','দীর্ঘমেয়াদি দায়','liability','credit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(23,1,22,'2210','Bank Loan','ব্যাংক ঋণ','liability','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(24,1,22,'2220','Other Loan','অন্যান্য ঋণ','liability','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(25,1,NULL,'3000','Equity','মূলধন','equity','credit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(26,1,25,'3100','Owner Capital','মালিকের মূলধন','equity','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(27,1,25,'3200','Drawings','উত্তোলন','equity','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(28,1,25,'3300','Retained Earnings','সঞ্চিত মুনাফা','equity','credit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(29,1,NULL,'4000','Income','আয়','income','credit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(30,1,29,'4100','Sales','বিক্রয়','income','credit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(31,1,29,'4200','Discount Received','প্রাপ্ত ছাড়','income','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(32,1,29,'4300','Other Income','অন্যান্য আয়','income','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(33,1,NULL,'5000','Expenses','খরচ','expense','debit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(34,1,33,'5100','Cost of Goods Sold','বিক্রীত পণ্যের ব্যয়','expense','debit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(35,1,33,'5200','Operating Expenses','পরিচালন ব্যয়','expense','debit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(36,1,35,'5201','Salary & Wages','বেতন ও মজুরি','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(37,1,35,'5202','Rent','ভাড়া','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(38,1,35,'5203','Electricity & Utilities','বিদ্যুৎ ও ইউটিলিটি','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(39,1,35,'5204','Fuel & Transport','জ্বালানি ও পরিবহন','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(40,1,35,'5205','Mobile & Internet','মোবাইল ও ইন্টারনেট','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(41,1,35,'5206','Repair & Maintenance','মেরামত ও রক্ষণাবেক্ষণ','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(42,1,35,'5207','Office Supplies','অফিস সরঞ্জাম','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(43,1,35,'5208','Entertainment','আপ্যায়ন','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(44,1,35,'5209','Marketing & Promotion','বিপণন ও প্রচার','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(45,1,35,'5210','Bank Charges','ব্যাংক চার্জ','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(46,1,35,'5211','Mobile Banking Charges','মোবাইল ব্যাংকিং চার্জ','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(47,1,35,'5212','Depreciation','অবচয়','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(48,1,35,'5213','Government Fees & Licences','সরকারি ফি ও লাইসেন্স','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(49,1,35,'5299','Miscellaneous Expenses','বিবিধ খরচ','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(50,1,33,'5300','Discount Given','প্রদত্ত ছাড়','expense','debit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(51,1,33,'5400','Bad Debt','অনাদায়ী পাওনা','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(52,2,NULL,'1000','Assets','সম্পদ','asset','debit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(53,2,52,'1100','Current Assets','চলতি সম্পদ','asset','debit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(54,2,53,'1101','Cash in Hand','হাতে নগদ','asset','debit',1,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(55,2,53,'1102','Bank & Mobile Money','ব্যাংক ও মোবাইল ব্যাংকিং','asset','debit',1,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(56,2,53,'1110','Accounts Receivable','প্রাপ্য হিসাব','asset','debit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(57,2,53,'1120','Inventory','মজুদ পণ্য','asset','debit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(58,2,53,'1130','Advance & Prepayments','অগ্রিম ও অগ্রিম পরিশোধ','asset','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(59,2,53,'1140','Security Deposits','জামানত','asset','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(60,2,52,'1200','Fixed Assets','স্থায়ী সম্পদ','asset','debit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(61,2,60,'1201','Furniture & Fixtures','আসবাবপত্র','asset','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(62,2,60,'1202','Vehicles','যানবাহন','asset','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(63,2,60,'1203','Equipment & Machinery','যন্ত্রপাতি','asset','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(64,2,60,'1204','Computer & Accessories','কম্পিউটার ও সরঞ্জাম','asset','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(65,2,60,'1290','Accumulated Depreciation','সঞ্চিত অবচয়','asset','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(66,2,NULL,'2000','Liabilities','দায়','liability','credit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(67,2,66,'2100','Current Liabilities','চলতি দায়','liability','credit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(68,2,67,'2110','Accounts Payable','প্রদেয় হিসাব','liability','credit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(69,2,67,'2120','VAT Payable','প্রদেয় ভ্যাট','liability','credit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(70,2,67,'2130','Salary Payable','প্রদেয় বেতন','liability','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(71,2,67,'2140','Expenses Payable','প্রদেয় খরচ','liability','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(72,2,67,'2150','Advance from Customers','গ্রাহকের অগ্রিম','liability','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(73,2,66,'2200','Long Term Liabilities','দীর্ঘমেয়াদি দায়','liability','credit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(74,2,73,'2210','Bank Loan','ব্যাংক ঋণ','liability','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(75,2,73,'2220','Other Loan','অন্যান্য ঋণ','liability','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(76,2,NULL,'3000','Equity','মূলধন','equity','credit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(77,2,76,'3100','Owner Capital','মালিকের মূলধন','equity','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(78,2,76,'3200','Drawings','উত্তোলন','equity','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(79,2,76,'3300','Retained Earnings','সঞ্চিত মুনাফা','equity','credit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(80,2,NULL,'4000','Income','আয়','income','credit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(81,2,80,'4100','Sales','বিক্রয়','income','credit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(82,2,80,'4200','Discount Received','প্রাপ্ত ছাড়','income','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(83,2,80,'4300','Other Income','অন্যান্য আয়','income','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(84,2,NULL,'5000','Expenses','খরচ','expense','debit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(85,2,84,'5100','Cost of Goods Sold','বিক্রীত পণ্যের ব্যয়','expense','debit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(86,2,84,'5200','Operating Expenses','পরিচালন ব্যয়','expense','debit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(87,2,86,'5201','Salary & Wages','বেতন ও মজুরি','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(88,2,86,'5202','Rent','ভাড়া','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(89,2,86,'5203','Electricity & Utilities','বিদ্যুৎ ও ইউটিলিটি','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(90,2,86,'5204','Fuel & Transport','জ্বালানি ও পরিবহন','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(91,2,86,'5205','Mobile & Internet','মোবাইল ও ইন্টারনেট','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(92,2,86,'5206','Repair & Maintenance','মেরামত ও রক্ষণাবেক্ষণ','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(93,2,86,'5207','Office Supplies','অফিস সরঞ্জাম','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(94,2,86,'5208','Entertainment','আপ্যায়ন','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(95,2,86,'5209','Marketing & Promotion','বিপণন ও প্রচার','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(96,2,86,'5210','Bank Charges','ব্যাংক চার্জ','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(97,2,86,'5211','Mobile Banking Charges','মোবাইল ব্যাংকিং চার্জ','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(98,2,86,'5212','Depreciation','অবচয়','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(99,2,86,'5213','Government Fees & Licences','সরকারি ফি ও লাইসেন্স','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(100,2,86,'5299','Miscellaneous Expenses','বিবিধ খরচ','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(101,2,84,'5300','Discount Given','প্রদত্ত ছাড়','expense','debit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(102,2,84,'5400','Bad Debt','অনাদায়ী পাওনা','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 04:39:04','2026-08-04 04:39:04',NULL),(103,1,3,'1101-CASH','Main Cash','প্রধান নগদ','asset','debit',0,1,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 05:07:10','2026-08-04 05:07:10',NULL),(104,1,3,'1101-COUNTER','Front Counter','সামনের কাউন্টার','asset','debit',0,1,0,0,12000.0000,'2026-08-01',NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 05:07:10','2026-08-04 05:07:10',NULL),(105,1,3,'1101-RIDER-A','Delivery — Rider A','ডেলিভারি — রাইডার এ','asset','debit',0,1,0,0,3500.0000,'2026-08-01',NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 05:07:10','2026-08-04 05:07:10',NULL),(106,1,4,'1102-BRAC','BRAC Bank — Current','ব্র্যাক ব্যাংক — চলতি','asset','debit',0,0,1,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,NULL,'2026-08-04 05:22:55','2026-08-04 05:22:55',NULL),(107,3,NULL,'1000','Assets','সম্পদ','asset','debit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(108,3,107,'1100','Current Assets','চলতি সম্পদ','asset','debit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(109,3,108,'1101','Cash in Hand','হাতে নগদ','asset','debit',1,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(110,3,108,'1102','Bank & Mobile Money','ব্যাংক ও মোবাইল ব্যাংকিং','asset','debit',1,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(111,3,108,'1110','Accounts Receivable','প্রাপ্য হিসাব','asset','debit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(112,3,108,'1120','Inventory','মজুদ পণ্য','asset','debit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(113,3,108,'1130','Advance & Prepayments','অগ্রিম ও অগ্রিম পরিশোধ','asset','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(114,3,108,'1140','Security Deposits','জামানত','asset','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(115,3,107,'1200','Fixed Assets','স্থায়ী সম্পদ','asset','debit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(116,3,115,'1201','Furniture & Fixtures','আসবাবপত্র','asset','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(117,3,115,'1202','Vehicles','যানবাহন','asset','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(118,3,115,'1203','Equipment & Machinery','যন্ত্রপাতি','asset','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(119,3,115,'1204','Computer & Accessories','কম্পিউটার ও সরঞ্জাম','asset','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(120,3,115,'1290','Accumulated Depreciation','সঞ্চিত অবচয়','asset','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(121,3,NULL,'2000','Liabilities','দায়','liability','credit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(122,3,121,'2100','Current Liabilities','চলতি দায়','liability','credit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(123,3,122,'2110','Accounts Payable','প্রদেয় হিসাব','liability','credit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(124,3,122,'2120','VAT Payable','প্রদেয় ভ্যাট','liability','credit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(125,3,122,'2130','Salary Payable','প্রদেয় বেতন','liability','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(126,3,122,'2140','Expenses Payable','প্রদেয় খরচ','liability','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(127,3,122,'2150','Advance from Customers','গ্রাহকের অগ্রিম','liability','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(128,3,121,'2200','Long Term Liabilities','দীর্ঘমেয়াদি দায়','liability','credit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(129,3,128,'2210','Bank Loan','ব্যাংক ঋণ','liability','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(130,3,128,'2220','Other Loan','অন্যান্য ঋণ','liability','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(131,3,NULL,'3000','Equity','মূলধন','equity','credit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(132,3,131,'3100','Owner Capital','মালিকের মূলধন','equity','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(133,3,131,'3200','Drawings','উত্তোলন','equity','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(134,3,131,'3300','Retained Earnings','সঞ্চিত মুনাফা','equity','credit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(135,3,NULL,'4000','Income','আয়','income','credit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(136,3,135,'4100','Sales','বিক্রয়','income','credit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(137,3,135,'4200','Discount Received','প্রাপ্ত ছাড়','income','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(138,3,135,'4300','Other Income','অন্যান্য আয়','income','credit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(139,3,NULL,'5000','Expenses','খরচ','expense','debit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(140,3,139,'5100','Cost of Goods Sold','বিক্রীত পণ্যের ব্যয়','expense','debit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(141,3,139,'5200','Operating Expenses','পরিচালন ব্যয়','expense','debit',1,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(142,3,141,'5201','Salary & Wages','বেতন ও মজুরি','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(143,3,141,'5202','Rent','ভাড়া','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(144,3,141,'5203','Electricity & Utilities','বিদ্যুৎ ও ইউটিলিটি','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(145,3,141,'5204','Fuel & Transport','জ্বালানি ও পরিবহন','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(146,3,141,'5205','Mobile & Internet','মোবাইল ও ইন্টারনেট','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(147,3,141,'5206','Repair & Maintenance','মেরামত ও রক্ষণাবেক্ষণ','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(148,3,141,'5207','Office Supplies','অফিস সরঞ্জাম','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(149,3,141,'5208','Entertainment','আপ্যায়ন','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(150,3,141,'5209','Marketing & Promotion','বিপণন ও প্রচার','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(151,3,141,'5210','Bank Charges','ব্যাংক চার্জ','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(152,3,141,'5211','Mobile Banking Charges','মোবাইল ব্যাংকিং চার্জ','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(153,3,141,'5212','Depreciation','অবচয়','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(154,3,141,'5213','Government Fees & Licences','সরকারি ফি ও লাইসেন্স','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(155,3,141,'5299','Miscellaneous Expenses','বিবিধ খরচ','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(156,3,139,'5300','Discount Given','প্রদত্ত ছাড়','expense','debit',0,0,0,1,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(157,3,139,'5400','Bad Debt','অনাদায়ী পাওনা','expense','debit',0,0,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(158,3,109,'1101-CASH','Main Cash','প্রধান নগদ','asset','debit',0,1,0,0,0.0000,NULL,NULL,NULL,NULL,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL);
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activity_log`
--

DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `log_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject_id` bigint unsigned DEFAULT NULL,
  `causer_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `causer_id` bigint unsigned DEFAULT NULL,
  `properties` json DEFAULT NULL,
  `batch_uuid` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subject` (`subject_type`,`subject_id`),
  KEY `causer` (`causer_type`,`causer_id`),
  KEY `activity_log_log_name_index` (`log_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_log`
--

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `approval_decisions`
--

DROP TABLE IF EXISTS `approval_decisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `approval_decisions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `approval_id` bigint unsigned NOT NULL,
  `level` int unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `decision` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `decided_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `approval_decisions_user_id_foreign` (`user_id`),
  KEY `approval_decisions_approval_id_level_index` (`approval_id`,`level`),
  CONSTRAINT `approval_decisions_approval_id_foreign` FOREIGN KEY (`approval_id`) REFERENCES `approvals` (`id`) ON DELETE CASCADE,
  CONSTRAINT `approval_decisions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `approval_decisions`
--

LOCK TABLES `approval_decisions` WRITE;
/*!40000 ALTER TABLE `approval_decisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `approval_decisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `approval_flow_steps`
--

DROP TABLE IF EXISTS `approval_flow_steps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `approval_flow_steps` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `approval_flow_id` bigint unsigned NOT NULL,
  `level` int unsigned NOT NULL,
  `approver_type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `approver_id` bigint unsigned NOT NULL,
  `requires_all` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `approval_step_unique` (`approval_flow_id`,`level`,`approver_type`,`approver_id`),
  CONSTRAINT `approval_flow_steps_approval_flow_id_foreign` FOREIGN KEY (`approval_flow_id`) REFERENCES `approval_flows` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `approval_flow_steps`
--

LOCK TABLES `approval_flow_steps` WRITE;
/*!40000 ALTER TABLE `approval_flow_steps` DISABLE KEYS */;
INSERT INTO `approval_flow_steps` VALUES (1,1,1,'user',1,0,'2026-08-04 01:13:07','2026-08-04 01:13:07');
/*!40000 ALTER TABLE `approval_flow_steps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `approval_flows`
--

DROP TABLE IF EXISTS `approval_flows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `approval_flows` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `module` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `document_type` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `threshold_amount` decimal(18,4) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `approval_flow_scope` (`company_id`,`module`,`action`,`document_type`),
  CONSTRAINT `approval_flows_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `approval_flows`
--

LOCK TABLES `approval_flows` WRITE;
/*!40000 ALTER TABLE `approval_flows` DISABLE KEYS */;
INSERT INTO `approval_flows` VALUES (1,1,'sales','discount',NULL,1000.0000,1,'2026-08-04 01:13:07','2026-08-04 01:13:07');
/*!40000 ALTER TABLE `approval_flows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `approvals`
--

DROP TABLE IF EXISTS `approvals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `approvals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `approvable_type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `approvable_id` bigint unsigned NOT NULL,
  `module` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(18,4) DEFAULT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `current_level` int unsigned NOT NULL DEFAULT '1',
  `payload` json DEFAULT NULL,
  `requested_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `requested_by` bigint unsigned NOT NULL,
  `requested_at` timestamp NOT NULL,
  `decided_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `approvals_requested_by_foreign` (`requested_by`),
  KEY `approval_queue` (`company_id`,`status`,`module`),
  KEY `approval_target` (`approvable_type`,`approvable_id`),
  CONSTRAINT `approvals_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `approvals_requested_by_foreign` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `approvals`
--

LOCK TABLES `approvals` WRITE;
/*!40000 ALTER TABLE `approvals` DISABLE KEYS */;
/*!40000 ALTER TABLE `approvals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachments`
--

DROP TABLE IF EXISTS `attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attachments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `source_module` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_entity` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_entity_id` bigint unsigned NOT NULL,
  `original_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stored_path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extension` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size_bytes` bigint unsigned NOT NULL,
  `checksum` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `replaces_id` bigint unsigned DEFAULT NULL,
  `uploaded_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `attachments_replaces_id_foreign` (`replaces_id`),
  KEY `attachments_uploaded_by_foreign` (`uploaded_by`),
  KEY `attachment_target` (`company_id`,`source_module`,`source_entity`,`source_entity_id`),
  CONSTRAINT `attachments_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `attachments_replaces_id_foreign` FOREIGN KEY (`replaces_id`) REFERENCES `attachments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `attachments_uploaded_by_foreign` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachments`
--

LOCK TABLES `attachments` WRITE;
/*!40000 ALTER TABLE `attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branches`
--

DROP TABLE IF EXISTS `branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `branches` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_bn` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_en` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_bn` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `branches_company_id_code_unique` (`company_id`,`code`),
  KEY `branches_company_id_is_active_index` (`company_id`,`is_active`),
  CONSTRAINT `branches_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branches`
--

LOCK TABLES `branches` WRITE;
/*!40000 ALTER TABLE `branches` DISABLE KEYS */;
INSERT INTO `branches` VALUES (1,1,'MMS','Main Mymensingh','প্রধান ময়মনসিংহ',NULL,NULL,NULL,1,1,'2026-08-04 01:13:06','2026-08-04 01:13:06',NULL),(2,1,'NTK','Netrakona','নেত্রকোনা',NULL,NULL,NULL,0,1,'2026-08-04 01:13:06','2026-08-04 01:13:06',NULL),(3,1,'DMD','Dumdy','ডুমডি',NULL,NULL,NULL,0,1,'2026-08-04 01:13:06','2026-08-04 01:13:06',NULL),(4,1,'KDA','Kendua','কেন্দুয়া',NULL,NULL,NULL,0,1,'2026-08-04 01:13:06','2026-08-04 01:13:06',NULL),(5,2,'MAIN','Main Office','প্রধান কার্যালয়',NULL,NULL,NULL,1,1,'2026-08-04 01:13:06','2026-08-04 01:13:06',NULL),(6,3,'SUPER','Star Line (Super)','স্টার লাইন (সুপার)',NULL,NULL,NULL,1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(7,3,'LION','Star Line (Lion)','স্টার লাইন (লায়ন)',NULL,NULL,NULL,0,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL),(8,3,'GOLD','Star Line (Gold)','স্টার লাইন (গোল্ড)',NULL,NULL,NULL,0,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL);
/*!40000 ALTER TABLE `branches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('abos-cache-5c785c036466adea360111aa28563bfd556b5fba','i:1;',1785859440),('abos-cache-5c785c036466adea360111aa28563bfd556b5fba:timer','i:1785859440;',1785859440),('abos-cache-spatie.permission.cache','a:3:{s:5:\"alias\";a:4:{s:1:\"a\";s:2:\"id\";s:1:\"b\";s:4:\"name\";s:1:\"c\";s:10:\"guard_name\";s:1:\"r\";s:5:\"roles\";}s:11:\"permissions\";a:38:{i:0;a:4:{s:1:\"a\";i:1;s:1:\"b\";s:13:\"accounts.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:1;a:4:{s:1:\"a\";i:2;s:1:\"b\";s:15:\"accounts.manage\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:2;a:4:{s:1:\"a\";i:3;s:1:\"b\";s:17:\"accounts.coa.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:3;a:4:{s:1:\"a\";i:4;s:1:\"b\";s:19:\"accounts.coa.manage\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:4;a:4:{s:1:\"a\";i:5;s:1:\"b\";s:23:\"accounts.voucher.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:5;a:4:{s:1:\"a\";i:6;s:1:\"b\";s:23:\"accounts.voucher.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:6;a:4:{s:1:\"a\";i:7;s:1:\"b\";s:23:\"accounts.voucher.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:7;a:4:{s:1:\"a\";i:8;s:1:\"b\";s:24:\"accounts.voucher.approve\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:8;a:4:{s:1:\"a\";i:9;s:1:\"b\";s:25:\"accounts.voucher.backdate\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:9;a:4:{s:1:\"a\";i:10;s:1:\"b\";s:15:\"accounts.report\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:10;a:4:{s:1:\"a\";i:11;s:1:\"b\";s:21:\"accounts.report.final\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:11;a:4:{s:1:\"a\";i:12;s:1:\"b\";s:18:\"accounts.till.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:12;a:4:{s:1:\"a\";i:13;s:1:\"b\";s:20:\"accounts.till.manage\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:13;a:4:{s:1:\"a\";i:14;s:1:\"b\";s:24:\"accounts.transfer.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:14;a:4:{s:1:\"a\";i:15;s:1:\"b\";s:25:\"accounts.transfer.confirm\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:15;a:4:{s:1:\"a\";i:16;s:1:\"b\";s:21:\"accounts.count.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:16;a:4:{s:1:\"a\";i:17;s:1:\"b\";s:22:\"accounts.count.approve\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:17;a:4:{s:1:\"a\";i:18;s:1:\"b\";s:13:\"customer.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:18;a:4:{s:1:\"a\";i:19;s:1:\"b\";s:15:\"customer.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:19;a:4:{s:1:\"a\";i:20;s:1:\"b\";s:15:\"customer.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:20;a:4:{s:1:\"a\";i:21;s:1:\"b\";s:15:\"customer.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:21;a:4:{s:1:\"a\";i:22;s:1:\"b\";s:15:\"customer.report\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:22;a:4:{s:1:\"a\";i:23;s:1:\"b\";s:15:\"customer.manage\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:23;a:4:{s:1:\"a\";i:24;s:1:\"b\";s:30:\"customer.credit_limit.override\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:24;a:4:{s:1:\"a\";i:25;s:1:\"b\";s:27:\"system_admin.company.manage\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:25;a:4:{s:1:\"a\";i:26;s:1:\"b\";s:24:\"system_admin.user.manage\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:26;a:4:{s:1:\"a\";i:27;s:1:\"b\";s:24:\"system_admin.role.manage\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:27;a:4:{s:1:\"a\";i:28;s:1:\"b\";s:28:\"system_admin.settings.manage\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:28;a:4:{s:1:\"a\";i:29;s:1:\"b\";s:23:\"system_admin.audit.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:29;a:4:{s:1:\"a\";i:30;s:1:\"b\";s:26:\"system_admin.backup.manage\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:30;a:4:{s:1:\"a\";i:31;s:1:\"b\";s:16:\"master_data.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:31;a:4:{s:1:\"a\";i:32;s:1:\"b\";s:18:\"master_data.manage\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:32;a:4:{s:1:\"a\";i:33;s:1:\"b\";s:13:\"supplier.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:33;a:4:{s:1:\"a\";i:34;s:1:\"b\";s:15:\"supplier.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:34;a:4:{s:1:\"a\";i:35;s:1:\"b\";s:15:\"supplier.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:35;a:4:{s:1:\"a\";i:36;s:1:\"b\";s:15:\"supplier.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:36;a:4:{s:1:\"a\";i:37;s:1:\"b\";s:15:\"supplier.report\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:37;a:4:{s:1:\"a\";i:38;s:1:\"b\";s:15:\"supplier.manage\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}}s:5:\"roles\";a:3:{i:0;a:3:{s:1:\"a\";i:1;s:1:\"b\";s:5:\"owner\";s:1:\"c\";s:3:\"web\";}i:1;a:3:{s:1:\"a\";i:2;s:1:\"b\";s:10:\"accountant\";s:1:\"c\";s:3:\"web\";}i:2;a:3:{s:1:\"a\";i:3;s:1:\"b\";s:8:\"salesman\";s:1:\"c\";s:3:\"web\";}}}',1785943884);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_counts`
--

DROP TABLE IF EXISTS `cash_counts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cash_counts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `branch_id` bigint unsigned DEFAULT NULL,
  `financial_year_id` bigint unsigned NOT NULL,
  `document_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trx_date` date NOT NULL,
  `cash_till_id` bigint unsigned NOT NULL,
  `counted_amount` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `expected_amount` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `difference` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `denominations` json DEFAULT NULL,
  `adjustment_voucher_id` bigint unsigned DEFAULT NULL,
  `narration` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `counted_by` bigint unsigned DEFAULT NULL,
  `approved_by` bigint unsigned DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cash_counts_company_id_document_no_unique` (`company_id`,`document_no`),
  KEY `cash_counts_branch_id_foreign` (`branch_id`),
  KEY `cash_counts_financial_year_id_foreign` (`financial_year_id`),
  KEY `cash_counts_cash_till_id_foreign` (`cash_till_id`),
  KEY `cash_counts_adjustment_voucher_id_foreign` (`adjustment_voucher_id`),
  KEY `cash_counts_counted_by_foreign` (`counted_by`),
  KEY `cash_counts_approved_by_foreign` (`approved_by`),
  KEY `cash_counts_created_by_foreign` (`created_by`),
  KEY `cash_counts_company_id_cash_till_id_trx_date_index` (`company_id`,`cash_till_id`,`trx_date`),
  CONSTRAINT `cash_counts_adjustment_voucher_id_foreign` FOREIGN KEY (`adjustment_voucher_id`) REFERENCES `vouchers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `cash_counts_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `cash_counts_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `cash_counts_cash_till_id_foreign` FOREIGN KEY (`cash_till_id`) REFERENCES `cash_tills` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cash_counts_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cash_counts_counted_by_foreign` FOREIGN KEY (`counted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `cash_counts_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `cash_counts_financial_year_id_foreign` FOREIGN KEY (`financial_year_id`) REFERENCES `financial_years` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_counts`
--

LOCK TABLES `cash_counts` WRITE;
/*!40000 ALTER TABLE `cash_counts` DISABLE KEYS */;
/*!40000 ALTER TABLE `cash_counts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_tills`
--

DROP TABLE IF EXISTS `cash_tills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cash_tills` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `branch_id` bigint unsigned DEFAULT NULL,
  `account_id` bigint unsigned NOT NULL,
  `code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_bn` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `holder_id` bigint unsigned DEFAULT NULL,
  `limit_amount` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `is_primary` tinyint(1) NOT NULL DEFAULT '0',
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'confirmed',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cash_tills_company_id_code_unique` (`company_id`,`code`),
  KEY `cash_tills_branch_id_foreign` (`branch_id`),
  KEY `cash_tills_account_id_foreign` (`account_id`),
  KEY `cash_tills_holder_id_foreign` (`holder_id`),
  KEY `cash_tills_created_by_foreign` (`created_by`),
  KEY `cash_tills_company_id_holder_id_index` (`company_id`,`holder_id`),
  KEY `cash_tills_company_id_is_active_index` (`company_id`,`is_active`),
  CONSTRAINT `cash_tills_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cash_tills_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `cash_tills_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cash_tills_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `cash_tills_holder_id_foreign` FOREIGN KEY (`holder_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_tills`
--

LOCK TABLES `cash_tills` WRITE;
/*!40000 ALTER TABLE `cash_tills` DISABLE KEYS */;
INSERT INTO `cash_tills` VALUES (1,1,1,103,'CASH','Main Cash','প্রধান নগদ',NULL,0.0000,1,'confirmed',1,1,'2026-08-04 05:07:10','2026-08-04 05:07:10',NULL),(2,1,1,104,'COUNTER','Front Counter','সামনের কাউন্টার',2,50000.0000,0,'confirmed',1,1,'2026-08-04 05:07:10','2026-08-04 05:07:10',NULL),(3,1,1,105,'RIDER-A','Delivery — Rider A','ডেলিভারি — রাইডার এ',3,20000.0000,0,'confirmed',1,1,'2026-08-04 05:07:10','2026-08-04 05:07:10',NULL),(4,3,6,158,'CASH','Main Cash','প্রধান নগদ',NULL,0.0000,1,'confirmed',1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02',NULL);
/*!40000 ALTER TABLE `cash_tills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `companies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_bn` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `legal_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_en` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_bn` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bin` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tin` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'BDT',
  `locale` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'bn',
  `timezone` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Asia/Dhaka',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `companies_code_unique` (`code`),
  KEY `companies_is_active_index` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companies`
--

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (1,'TDEPOT','Trade Depot','ট্রেড ডিপো',NULL,'Ganginar Par, Mymensingh 2200','গাঙ্গিনার পাড়, ময়মনসিংহ ২২০০','+8801700000000',NULL,NULL,'000123456-0101',NULL,'logos/Trade Depot.png','BDT','bn','Asia/Dhaka',1,'2026-08-04 01:13:06','2026-08-04 01:13:06',NULL),(2,'FMART','Family Mart','ফ্যামিলি মার্ট',NULL,'Charpara, Mymensingh 2200','চরপাড়া, ময়মনসিংহ ২২০০','+8801700000001',NULL,NULL,NULL,NULL,'logos/FamilyMart.png','BDT','bn','Asia/Dhaka',1,'2026-08-04 01:13:06','2026-08-04 01:13:06',NULL),(3,'ADI','Adi Corporation','আদি কর্পোরেশন','Adi Corporation',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'logos/Adi Corporation.png','BDT','bn','Asia/Dhaka',1,'2026-08-04 07:23:01','2026-08-04 07:50:49',NULL);
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company_user`
--

DROP TABLE IF EXISTS `company_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `company_user` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `default_branch_id` bigint unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `company_user_company_id_user_id_unique` (`company_id`,`user_id`),
  KEY `company_user_default_branch_id_foreign` (`default_branch_id`),
  KEY `company_user_user_id_is_active_index` (`user_id`,`is_active`),
  CONSTRAINT `company_user_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `company_user_default_branch_id_foreign` FOREIGN KEY (`default_branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `company_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company_user`
--

LOCK TABLES `company_user` WRITE;
/*!40000 ALTER TABLE `company_user` DISABLE KEYS */;
INSERT INTO `company_user` VALUES (1,1,1,NULL,1,'2026-08-04 01:13:07','2026-08-04 01:13:07'),(2,2,1,NULL,1,'2026-08-04 01:13:07','2026-08-04 01:13:07'),(3,1,2,NULL,1,'2026-08-04 01:13:07','2026-08-04 01:13:07'),(4,1,3,NULL,1,'2026-08-04 01:13:07','2026-08-04 01:13:07'),(5,3,1,6,1,'2026-08-04 07:23:02','2026-08-04 07:23:53');
/*!40000 ALTER TABLE `company_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `branch_id` bigint unsigned DEFAULT NULL,
  `code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_bn` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_en` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_bn` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_type` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `party_type_id` bigint unsigned DEFAULT NULL,
  `credit_limit` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `credit_days` smallint unsigned NOT NULL DEFAULT '0',
  `opening_balance` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `opening_date` date DEFAULT NULL,
  `receivable_account_id` bigint unsigned DEFAULT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'confirmed',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customers_company_id_code_unique` (`company_id`,`code`),
  KEY `customers_branch_id_foreign` (`branch_id`),
  KEY `customers_created_by_foreign` (`created_by`),
  KEY `customers_company_id_is_active_index` (`company_id`,`is_active`),
  KEY `customers_company_id_name_en_index` (`company_id`,`name_en`),
  KEY `customers_company_id_phone_index` (`company_id`,`phone`),
  KEY `customers_party_type_id_foreign` (`party_type_id`),
  CONSTRAINT `customers_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `customers_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `customers_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `customers_party_type_id_foreign` FOREIGN KEY (`party_type_id`) REFERENCES `mdm_party_types` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,1,1,'CUS-2026-2027-0001','Karim General Store','করিম জেনারেল স্টোর','01711100200',NULL,NULL,NULL,'খুচরা',6,50000.0000,15,12000.0000,'2026-07-01',NULL,'confirmed',1,1,'2026-08-04 03:53:46','2026-08-04 03:53:46',NULL),(2,1,1,'CUS-2026-2027-0002','Rahim Traders','রহিম ট্রেডার্স','01812300400',NULL,NULL,NULL,'পাইকারি',7,200000.0000,30,0.0000,NULL,NULL,'confirmed',1,1,'2026-08-04 03:53:46','2026-08-04 03:53:46',NULL),(3,1,1,'CUS-2026-2027-0003','Nur Enterprise','নূর এন্টারপ্রাইজ','01913400500',NULL,NULL,NULL,'পাইকারি',7,0.0000,30,35000.0000,'2026-07-01',NULL,'confirmed',1,1,'2026-08-04 03:53:46','2026-08-04 03:53:46',NULL),(4,1,1,'CUS-2026-2027-0004','Bismillah Store','বিসমিল্লাহ স্টোর','01614500600',NULL,NULL,NULL,'খুচরা',6,25000.0000,7,0.0000,NULL,NULL,'confirmed',1,1,'2026-08-04 03:53:46','2026-08-04 03:53:46',NULL),(5,1,1,'CUS-2026-2027-0005','Netrakona Depot','নেত্রকোনা ডিপো','01515600700',NULL,NULL,NULL,'প্রতিষ্ঠান',9,100000.0000,45,8500.0000,'2026-07-01',NULL,'confirmed',1,1,'2026-08-04 03:53:46','2026-08-04 03:53:46',NULL);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `financial_years`
--

DROP TABLE IF EXISTS `financial_years`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `financial_years` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `starts_on` date NOT NULL,
  `ends_on` date NOT NULL,
  `is_closed` tinyint(1) NOT NULL DEFAULT '0',
  `closed_at` timestamp NULL DEFAULT NULL,
  `closed_by` bigint unsigned DEFAULT NULL,
  `is_current` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `financial_years_company_id_name_unique` (`company_id`,`name`),
  KEY `financial_years_closed_by_foreign` (`closed_by`),
  KEY `financial_years_company_id_starts_on_ends_on_index` (`company_id`,`starts_on`,`ends_on`),
  CONSTRAINT `financial_years_closed_by_foreign` FOREIGN KEY (`closed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `financial_years_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `financial_years`
--

LOCK TABLES `financial_years` WRITE;
/*!40000 ALTER TABLE `financial_years` DISABLE KEYS */;
INSERT INTO `financial_years` VALUES (1,1,'2026-2027','2026-07-01','2027-06-30',0,NULL,NULL,1,'2026-08-04 01:13:06','2026-08-04 01:13:06'),(2,2,'2026-2027','2026-07-01','2027-06-30',0,NULL,NULL,1,'2026-08-04 01:13:06','2026-08-04 01:13:06'),(3,3,'2026-2027','2026-07-01','2027-06-30',0,NULL,NULL,1,'2026-08-04 07:23:02','2026-08-04 07:23:02');
/*!40000 ALTER TABLE `financial_years` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issued_numbers`
--

DROP TABLE IF EXISTS `issued_numbers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `issued_numbers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `number_series_id` bigint unsigned NOT NULL,
  `document_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sequence` bigint unsigned NOT NULL,
  `source_type` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_id` bigint unsigned DEFAULT NULL,
  `issued_by` bigint unsigned DEFAULT NULL,
  `issued_at` timestamp NOT NULL,
  `is_voided` tinyint(1) NOT NULL DEFAULT '0',
  `void_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `issued_numbers_company_id_document_no_unique` (`company_id`,`document_no`),
  KEY `issued_numbers_number_series_id_foreign` (`number_series_id`),
  KEY `issued_numbers_issued_by_foreign` (`issued_by`),
  KEY `issued_numbers_source_type_source_id_index` (`source_type`,`source_id`),
  CONSTRAINT `issued_numbers_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `issued_numbers_issued_by_foreign` FOREIGN KEY (`issued_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `issued_numbers_number_series_id_foreign` FOREIGN KEY (`number_series_id`) REFERENCES `number_series` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issued_numbers`
--

LOCK TABLES `issued_numbers` WRITE;
/*!40000 ALTER TABLE `issued_numbers` DISABLE KEYS */;
INSERT INTO `issued_numbers` VALUES (1,1,10,'CUS-2026-2027-0001',1,'customer',1,1,'2026-08-04 03:53:46',0,NULL,'2026-08-04 03:53:46','2026-08-04 03:53:46'),(2,1,10,'CUS-2026-2027-0002',2,'customer',2,1,'2026-08-04 03:53:46',0,NULL,'2026-08-04 03:53:46','2026-08-04 03:53:46'),(3,1,10,'CUS-2026-2027-0003',3,'customer',3,1,'2026-08-04 03:53:46',0,NULL,'2026-08-04 03:53:46','2026-08-04 03:53:46'),(4,1,10,'CUS-2026-2027-0004',4,'customer',4,1,'2026-08-04 03:53:46',0,NULL,'2026-08-04 03:53:46','2026-08-04 03:53:46'),(5,1,10,'CUS-2026-2027-0005',5,'customer',5,1,'2026-08-04 03:53:46',0,NULL,'2026-08-04 03:53:46','2026-08-04 03:53:46'),(6,1,4,'RCV-2026-2027-0001',1,'receipt_voucher',1,1,'2026-08-04 05:22:55',0,NULL,'2026-08-04 05:22:55','2026-08-04 05:22:55'),(7,1,5,'PAY-2026-2027-0001',1,'payment_voucher',2,1,'2026-08-04 05:22:55',0,NULL,'2026-08-04 05:22:55','2026-08-04 05:22:55'),(8,1,4,'RCV-2026-2027-0002',2,'receipt_voucher',3,1,'2026-08-04 05:26:06',0,NULL,'2026-08-04 05:26:06','2026-08-04 05:26:06'),(9,1,5,'PAY-2026-2027-0002',2,'payment_voucher',4,1,'2026-08-04 05:26:06',0,NULL,'2026-08-04 05:26:06','2026-08-04 05:26:06'),(10,1,21,'EXP-2026-2027-0001',1,'expense_voucher',5,1,'2026-08-04 05:26:06',0,NULL,'2026-08-04 05:26:06','2026-08-04 05:26:06'),(11,1,4,'RCV-2026-2027-0003',3,'receipt_voucher',6,1,'2026-08-04 05:26:26',0,NULL,'2026-08-04 05:26:26','2026-08-04 05:26:26'),(12,1,5,'PAY-2026-2027-0003',3,'payment_voucher',7,1,'2026-08-04 05:26:26',0,NULL,'2026-08-04 05:26:26','2026-08-04 05:26:26'),(13,1,21,'EXP-2026-2027-0002',2,'expense_voucher',8,1,'2026-08-04 05:26:26',0,NULL,'2026-08-04 05:26:26','2026-08-04 05:26:26'),(14,1,7,'CON-2026-2027-0001',1,'contra_voucher',9,1,'2026-08-04 05:26:26',0,NULL,'2026-08-04 05:26:26','2026-08-04 05:26:26'),(15,1,6,'JRN-2026-2027-0001',1,'journal_voucher',10,1,'2026-08-04 05:26:26',0,NULL,'2026-08-04 05:26:26','2026-08-04 05:26:26'),(16,1,4,'RCV-2026-2027-0004',4,'receipt_voucher',11,1,'2026-08-04 05:27:26',0,NULL,'2026-08-04 05:27:26','2026-08-04 05:27:26'),(17,1,5,'PAY-2026-2027-0004',4,'payment_voucher',12,1,'2026-08-04 05:27:26',0,NULL,'2026-08-04 05:27:26','2026-08-04 05:27:26'),(18,1,21,'EXP-2026-2027-0003',3,'expense_voucher',13,1,'2026-08-04 05:27:26',0,NULL,'2026-08-04 05:27:26','2026-08-04 05:27:26'),(19,1,7,'CON-2026-2027-0002',2,'contra_voucher',14,1,'2026-08-04 05:27:26',0,NULL,'2026-08-04 05:27:26','2026-08-04 05:27:26'),(20,1,6,'JRN-2026-2027-0002',2,'journal_voucher',15,1,'2026-08-04 05:27:27',0,NULL,'2026-08-04 05:27:27','2026-08-04 05:27:27'),(21,1,31,'SUP-2026-2027-0001',1,'supplier',1,NULL,'2026-08-04 08:48:52',0,NULL,'2026-08-04 08:48:52','2026-08-04 08:48:52'),(22,1,31,'SUP-2026-2027-0002',2,'supplier',2,NULL,'2026-08-04 08:48:52',0,NULL,'2026-08-04 08:48:52','2026-08-04 08:48:52'),(23,1,31,'SUP-2026-2027-0003',3,'supplier',3,NULL,'2026-08-04 08:48:52',0,NULL,'2026-08-04 08:48:52','2026-08-04 08:48:52'),(24,1,31,'SUP-2026-2027-0004',4,'supplier',4,NULL,'2026-08-04 08:48:52',0,NULL,'2026-08-04 08:48:52','2026-08-04 08:48:52');
/*!40000 ALTER TABLE `issued_numbers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ledger_entries`
--

DROP TABLE IF EXISTS `ledger_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ledger_entries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `branch_id` bigint unsigned DEFAULT NULL,
  `financial_year_id` bigint unsigned NOT NULL,
  `account_id` bigint unsigned NOT NULL,
  `party_type` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `party_id` bigint unsigned DEFAULT NULL,
  `trx_date` date NOT NULL,
  `debit` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `credit` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `source_type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_id` bigint unsigned NOT NULL,
  `source_line_id` bigint unsigned DEFAULT NULL,
  `document_no` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `narration` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ledger_entries_branch_id_foreign` (`branch_id`),
  KEY `ledger_entries_financial_year_id_foreign` (`financial_year_id`),
  KEY `ledger_entries_created_by_foreign` (`created_by`),
  KEY `ledger_company_date` (`company_id`,`trx_date`),
  KEY `ledger_company_account_date` (`company_id`,`account_id`,`trx_date`),
  KEY `ledger_party` (`company_id`,`party_type`,`party_id`,`trx_date`),
  KEY `ledger_source` (`source_type`,`source_id`),
  CONSTRAINT `ledger_entries_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ledger_entries_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ledger_entries_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ledger_entries_financial_year_id_foreign` FOREIGN KEY (`financial_year_id`) REFERENCES `financial_years` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ledger_entries`
--

LOCK TABLES `ledger_entries` WRITE;
/*!40000 ALTER TABLE `ledger_entries` DISABLE KEYS */;
INSERT INTO `ledger_entries` VALUES (1,1,1,1,1101,'customer',1,'2026-08-01',11500.0000,0.0000,'sales_invoice',9001,NULL,'INV-2026-2027-0009',NULL,1,'2026-08-04 03:53:46','2026-08-04 03:53:46'),(2,1,1,1,4001,NULL,NULL,'2026-08-01',0.0000,11500.0000,'sales_invoice',9001,NULL,'INV-2026-2027-0009',NULL,1,'2026-08-04 03:53:46','2026-08-04 03:53:46'),(3,1,1,1,1001,NULL,NULL,'2026-08-03',5000.0000,0.0000,'receipt_voucher',9002,NULL,'RCV-2026-2027-0004',NULL,1,'2026-08-04 03:53:46','2026-08-04 03:53:46'),(4,1,1,1,1101,'customer',1,'2026-08-03',0.0000,5000.0000,'receipt_voucher',9002,NULL,'RCV-2026-2027-0004',NULL,1,'2026-08-04 03:53:46','2026-08-04 03:53:46'),(5,1,1,1,1101,'customer',3,'2026-08-02',22000.0000,0.0000,'sales_invoice',9003,NULL,'INV-2026-2027-0010',NULL,1,'2026-08-04 03:53:46','2026-08-04 03:53:46'),(6,1,1,1,4001,NULL,NULL,'2026-08-02',0.0000,22000.0000,'sales_invoice',9003,NULL,'INV-2026-2027-0010',NULL,1,'2026-08-04 03:53:46','2026-08-04 03:53:46'),(27,1,1,1,104,'customer',1,'2026-08-04',5000.0000,0.0000,'receipt_voucher',11,21,'RCV-2026-2027-0004','করিম স্টোর থেকে আদায়',1,'2026-08-04 05:27:26','2026-08-04 05:27:26'),(28,1,1,1,5,'customer',1,'2026-08-04',0.0000,5000.0000,'receipt_voucher',11,22,'RCV-2026-2027-0004','করিম স্টোর থেকে আদায়',1,'2026-08-04 05:27:26','2026-08-04 05:27:26'),(29,1,1,1,17,NULL,NULL,'2026-08-04',3000.0000,0.0000,'payment_voucher',12,23,'PAY-2026-2027-0004','সরবরাহকারীকে পরিশোধ',1,'2026-08-04 05:27:26','2026-08-04 05:27:26'),(30,1,1,1,104,NULL,NULL,'2026-08-04',0.0000,3000.0000,'payment_voucher',12,24,'PAY-2026-2027-0004','সরবরাহকারীকে পরিশোধ',1,'2026-08-04 05:27:26','2026-08-04 05:27:26'),(31,1,1,1,37,NULL,NULL,'2026-08-04',8000.0000,0.0000,'expense_voucher',13,25,'EXP-2026-2027-0003','আগস্টের দোকান ভাড়া',1,'2026-08-04 05:27:26','2026-08-04 05:27:26'),(32,1,1,1,104,NULL,NULL,'2026-08-04',0.0000,8000.0000,'expense_voucher',13,26,'EXP-2026-2027-0003','আগস্টের দোকান ভাড়া',1,'2026-08-04 05:27:26','2026-08-04 05:27:26'),(33,1,1,1,106,NULL,NULL,'2026-08-04',4000.0000,0.0000,'contra_voucher',14,27,'CON-2026-2027-0002','ব্যাংকে জমা',1,'2026-08-04 05:27:27','2026-08-04 05:27:27'),(34,1,1,1,104,NULL,NULL,'2026-08-04',0.0000,4000.0000,'contra_voucher',14,28,'CON-2026-2027-0002','ব্যাংকে জমা',1,'2026-08-04 05:27:27','2026-08-04 05:27:27'),(35,1,1,1,47,NULL,NULL,'2026-08-04',4500.0000,0.0000,'journal_voucher',15,29,'JRN-2026-2027-0002','আগস্টের অবচয়',1,'2026-08-04 05:27:27','2026-08-04 05:27:27'),(36,1,1,1,14,NULL,NULL,'2026-08-04',0.0000,4500.0000,'journal_voucher',15,30,'JRN-2026-2027-0002','আগস্টের অবচয়',1,'2026-08-04 05:27:27','2026-08-04 05:27:27'),(37,1,NULL,1,5,'customer',1,'2026-07-01',12000.0000,0.0000,'customer:opening',1,NULL,'CUS-2026-2027-0001','খোলা ব্যালেন্স',NULL,'2026-08-04 08:55:00','2026-08-04 08:55:00'),(38,1,NULL,1,28,NULL,NULL,'2026-07-01',0.0000,12000.0000,'customer:opening',1,NULL,'CUS-2026-2027-0001','খোলা ব্যালেন্স',NULL,'2026-08-04 08:55:00','2026-08-04 08:55:00'),(39,1,NULL,1,5,'customer',3,'2026-07-01',35000.0000,0.0000,'customer:opening',3,NULL,'CUS-2026-2027-0003','খোলা ব্যালেন্স',NULL,'2026-08-04 08:55:00','2026-08-04 08:55:00'),(40,1,NULL,1,28,NULL,NULL,'2026-07-01',0.0000,35000.0000,'customer:opening',3,NULL,'CUS-2026-2027-0003','খোলা ব্যালেন্স',NULL,'2026-08-04 08:55:00','2026-08-04 08:55:00'),(41,1,NULL,1,5,'customer',5,'2026-07-01',8500.0000,0.0000,'customer:opening',5,NULL,'CUS-2026-2027-0005','খোলা ব্যালেন্স',NULL,'2026-08-04 08:55:00','2026-08-04 08:55:00'),(42,1,NULL,1,28,NULL,NULL,'2026-07-01',0.0000,8500.0000,'customer:opening',5,NULL,'CUS-2026-2027-0005','খোলা ব্যালেন্স',NULL,'2026-08-04 08:55:00','2026-08-04 08:55:00'),(43,1,NULL,1,17,'supplier',1,'2026-07-01',0.0000,125000.0000,'supplier:opening',1,NULL,'SUP-2026-2027-0001','খোলা ব্যালেন্স',NULL,'2026-08-04 08:55:00','2026-08-04 08:55:00'),(44,1,NULL,1,28,NULL,NULL,'2026-07-01',125000.0000,0.0000,'supplier:opening',1,NULL,'SUP-2026-2027-0001','খোলা ব্যালেন্স',NULL,'2026-08-04 08:55:00','2026-08-04 08:55:00'),(45,1,NULL,1,17,'supplier',2,'2026-07-01',0.0000,48500.0000,'supplier:opening',2,NULL,'SUP-2026-2027-0002','খোলা ব্যালেন্স',NULL,'2026-08-04 08:55:00','2026-08-04 08:55:00'),(46,1,NULL,1,28,NULL,NULL,'2026-07-01',48500.0000,0.0000,'supplier:opening',2,NULL,'SUP-2026-2027-0002','খোলা ব্যালেন্স',NULL,'2026-08-04 08:55:00','2026-08-04 08:55:00'),(47,1,NULL,1,17,'supplier',4,'2026-07-01',0.0000,7200.0000,'supplier:opening',4,NULL,'SUP-2026-2027-0004','খোলা ব্যালেন্স',NULL,'2026-08-04 08:55:00','2026-08-04 08:55:00'),(48,1,NULL,1,28,NULL,NULL,'2026-07-01',7200.0000,0.0000,'supplier:opening',4,NULL,'SUP-2026-2027-0004','খোলা ব্যালেন্স',NULL,'2026-08-04 08:55:00','2026-08-04 08:55:00');
/*!40000 ALTER TABLE `ledger_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdm_locations`
--

DROP TABLE IF EXISTS `mdm_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mdm_locations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `parent_id` bigint unsigned DEFAULT NULL,
  `code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_bn` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `level` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `assigned_to` bigint unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdm_locations_company_id_code_unique` (`company_id`,`code`),
  KEY `mdm_locations_parent_id_foreign` (`parent_id`),
  KEY `mdm_locations_assigned_to_foreign` (`assigned_to`),
  KEY `mdm_locations_created_by_foreign` (`created_by`),
  KEY `mdm_locations_company_id_level_is_active_index` (`company_id`,`level`,`is_active`),
  KEY `mdm_locations_company_id_parent_id_index` (`company_id`,`parent_id`),
  CONSTRAINT `mdm_locations_assigned_to_foreign` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `mdm_locations_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mdm_locations_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `mdm_locations_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `mdm_locations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdm_locations`
--

LOCK TABLES `mdm_locations` WRITE;
/*!40000 ALTER TABLE `mdm_locations` DISABLE KEYS */;
INSERT INTO `mdm_locations` VALUES (1,3,NULL,'BD','Bangladesh','বাংলাদেশ','country',NULL,1,1,'2026-08-04 07:23:03','2026-08-04 07:23:03',NULL),(2,3,1,'DHA','Dhaka','ঢাকা','division',NULL,1,1,'2026-08-04 07:23:03','2026-08-04 07:23:03',NULL),(3,3,1,'CTG','Chattogram','চট্টগ্রাম','division',NULL,1,1,'2026-08-04 07:23:03','2026-08-04 07:23:03',NULL),(4,3,1,'KHU','Khulna','খুলনা','division',NULL,1,1,'2026-08-04 07:23:03','2026-08-04 07:23:03',NULL),(5,3,1,'RAJ','Rajshahi','রাজশাহী','division',NULL,1,1,'2026-08-04 07:23:03','2026-08-04 07:23:03',NULL),(6,3,1,'BAR','Barishal','বরিশাল','division',NULL,1,1,'2026-08-04 07:23:03','2026-08-04 07:23:03',NULL),(7,3,1,'SYL','Sylhet','সিলেট','division',NULL,1,1,'2026-08-04 07:23:03','2026-08-04 07:23:03',NULL),(8,3,1,'RNG','Rangpur','রংপুর','division',NULL,1,1,'2026-08-04 07:23:03','2026-08-04 07:23:03',NULL),(9,3,1,'MYM','Mymensingh','ময়মনসিংহ','division',NULL,1,1,'2026-08-04 07:23:03','2026-08-04 07:23:03',NULL),(10,1,NULL,'BD','Bangladesh','বাংলাদেশ','country',NULL,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(11,1,10,'DHA','Dhaka','ঢাকা','division',NULL,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(12,1,10,'CTG','Chattogram','চট্টগ্রাম','division',NULL,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(13,1,10,'KHU','Khulna','খুলনা','division',NULL,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(14,1,10,'RAJ','Rajshahi','রাজশাহী','division',NULL,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(15,1,10,'BAR','Barishal','বরিশাল','division',NULL,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(16,1,10,'SYL','Sylhet','সিলেট','division',NULL,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(17,1,10,'RNG','Rangpur','রংপুর','division',NULL,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(18,1,10,'MYM','Mymensingh','ময়মনসিংহ','division',NULL,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(19,2,NULL,'BD','Bangladesh','বাংলাদেশ','country',NULL,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(20,2,19,'DHA','Dhaka','ঢাকা','division',NULL,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(21,2,19,'CTG','Chattogram','চট্টগ্রাম','division',NULL,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(22,2,19,'KHU','Khulna','খুলনা','division',NULL,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(23,2,19,'RAJ','Rajshahi','রাজশাহী','division',NULL,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(24,2,19,'BAR','Barishal','বরিশাল','division',NULL,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(25,2,19,'SYL','Sylhet','সিলেট','division',NULL,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(26,2,19,'RNG','Rangpur','রংপুর','division',NULL,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(27,2,19,'MYM','Mymensingh','ময়মনসিংহ','division',NULL,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL);
/*!40000 ALTER TABLE `mdm_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdm_party_types`
--

DROP TABLE IF EXISTS `mdm_party_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mdm_party_types` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `code` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_bn` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `applies_to` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'customer',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdm_party_types_company_id_code_unique` (`company_id`,`code`),
  KEY `mdm_party_types_created_by_foreign` (`created_by`),
  CONSTRAINT `mdm_party_types_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mdm_party_types_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdm_party_types`
--

LOCK TABLES `mdm_party_types` WRITE;
/*!40000 ALTER TABLE `mdm_party_types` DISABLE KEYS */;
INSERT INTO `mdm_party_types` VALUES (1,3,'RETAIL','Retail','খুচরা','customer',1,1,1,'2026-08-04 07:23:54','2026-08-04 07:23:54',NULL),(2,3,'WHOLE','Wholesale','পাইকারি','customer',0,1,1,'2026-08-04 07:23:54','2026-08-04 07:23:54',NULL),(3,3,'DEALER','Dealer','ডিলার','customer',0,1,1,'2026-08-04 07:23:54','2026-08-04 07:23:54',NULL),(4,3,'INST','Institution','প্রতিষ্ঠান','both',0,1,1,'2026-08-04 07:23:54','2026-08-04 07:23:54',NULL),(5,3,'VENDOR','Vendor','সরবরাহকারী','supplier',0,1,1,'2026-08-04 07:23:54','2026-08-04 07:23:54',NULL),(6,1,'RETAIL','Retail','খুচরা','customer',1,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(7,1,'WHOLE','Wholesale','পাইকারি','customer',0,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(8,1,'DEALER','Dealer','ডিলার','customer',0,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(9,1,'INST','Institution','প্রতিষ্ঠান','both',0,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(10,1,'VENDOR','Vendor','সরবরাহকারী','supplier',0,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(11,2,'RETAIL','Retail','খুচরা','customer',1,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL),(12,2,'WHOLE','Wholesale','পাইকারি','customer',0,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL),(13,2,'DEALER','Dealer','ডিলার','customer',0,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL),(14,2,'INST','Institution','প্রতিষ্ঠান','both',0,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL),(15,2,'VENDOR','Vendor','সরবরাহকারী','supplier',0,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL);
/*!40000 ALTER TABLE `mdm_party_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdm_payment_terms`
--

DROP TABLE IF EXISTS `mdm_payment_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mdm_payment_terms` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `code` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_bn` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `days` smallint unsigned NOT NULL DEFAULT '0',
  `early_discount_percent` decimal(8,4) NOT NULL DEFAULT '0.0000',
  `early_discount_days` smallint unsigned NOT NULL DEFAULT '0',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdm_payment_terms_company_id_code_unique` (`company_id`,`code`),
  KEY `mdm_payment_terms_created_by_foreign` (`created_by`),
  CONSTRAINT `mdm_payment_terms_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mdm_payment_terms_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdm_payment_terms`
--

LOCK TABLES `mdm_payment_terms` WRITE;
/*!40000 ALTER TABLE `mdm_payment_terms` DISABLE KEYS */;
INSERT INTO `mdm_payment_terms` VALUES (1,3,'CASH','Cash','নগদ',0,0.0000,0,1,1,1,'2026-08-04 07:23:54','2026-08-04 07:23:54',NULL),(2,3,'NET7','7 days','৭ দিন',7,0.0000,0,0,1,1,'2026-08-04 07:23:54','2026-08-04 07:23:54',NULL),(3,3,'NET15','15 days','১৫ দিন',15,0.0000,0,0,1,1,'2026-08-04 07:23:54','2026-08-04 07:23:54',NULL),(4,3,'NET30','30 days','৩০ দিন',30,0.0000,0,0,1,1,'2026-08-04 07:23:54','2026-08-04 07:23:54',NULL),(5,1,'CASH','Cash','নগদ',0,0.0000,0,1,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(6,1,'NET7','7 days','৭ দিন',7,0.0000,0,0,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(7,1,'NET15','15 days','১৫ দিন',15,0.0000,0,0,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(8,1,'NET30','30 days','৩০ দিন',30,0.0000,0,0,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(9,2,'CASH','Cash','নগদ',0,0.0000,0,1,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL),(10,2,'NET7','7 days','৭ দিন',7,0.0000,0,0,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL),(11,2,'NET15','15 days','১৫ দিন',15,0.0000,0,0,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL),(12,2,'NET30','30 days','৩০ দিন',30,0.0000,0,0,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL);
/*!40000 ALTER TABLE `mdm_payment_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdm_price_lists`
--

DROP TABLE IF EXISTS `mdm_price_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mdm_price_lists` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `code` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_bn` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `party_type_id` bigint unsigned DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdm_price_lists_company_id_code_unique` (`company_id`,`code`),
  KEY `mdm_price_lists_created_by_foreign` (`created_by`),
  CONSTRAINT `mdm_price_lists_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mdm_price_lists_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdm_price_lists`
--

LOCK TABLES `mdm_price_lists` WRITE;
/*!40000 ALTER TABLE `mdm_price_lists` DISABLE KEYS */;
INSERT INTO `mdm_price_lists` VALUES (1,3,'RETAIL','Retail Price','খুচরা দর',NULL,1,1,1,'2026-08-04 07:23:54','2026-08-04 07:23:54',NULL),(2,3,'WHOLE','Wholesale Price','পাইকারি দর',NULL,0,1,1,'2026-08-04 07:23:54','2026-08-04 07:23:54',NULL),(3,1,'RETAIL','Retail Price','খুচরা দর',NULL,1,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(4,1,'WHOLE','Wholesale Price','পাইকারি দর',NULL,0,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(5,2,'RETAIL','Retail Price','খুচরা দর',NULL,1,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL),(6,2,'WHOLE','Wholesale Price','পাইকারি দর',NULL,0,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL);
/*!40000 ALTER TABLE `mdm_price_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdm_reason_codes`
--

DROP TABLE IF EXISTS `mdm_reason_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mdm_reason_codes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `code` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_bn` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `context` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `returns_to_stock` tinyint(1) NOT NULL DEFAULT '1',
  `needs_approval` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdm_reason_codes_company_id_code_unique` (`company_id`,`code`),
  KEY `mdm_reason_codes_created_by_foreign` (`created_by`),
  KEY `mdm_reason_codes_company_id_context_is_active_index` (`company_id`,`context`,`is_active`),
  CONSTRAINT `mdm_reason_codes_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mdm_reason_codes_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdm_reason_codes`
--

LOCK TABLES `mdm_reason_codes` WRITE;
/*!40000 ALTER TABLE `mdm_reason_codes` DISABLE KEYS */;
INSERT INTO `mdm_reason_codes` VALUES (1,3,'DAMAGE','Damaged goods','ক্ষতিগ্রস্ত পণ্য','sales_return',0,0,1,1,'2026-08-04 07:23:54','2026-08-04 07:23:54',NULL),(2,3,'EXPIRED','Expired','মেয়াদোত্তীর্ণ','sales_return',0,0,1,1,'2026-08-04 07:23:54','2026-08-04 07:23:54',NULL),(3,3,'WRONG','Wrong item delivered','ভুল পণ্য দেওয়া হয়েছে','sales_return',1,0,1,1,'2026-08-04 07:23:54','2026-08-04 07:23:54',NULL),(4,3,'UNSOLD','Not sold','বিক্রি হয়নি','sales_return',1,0,1,1,'2026-08-04 07:23:54','2026-08-04 07:23:54',NULL),(5,3,'COUNT','Counting difference','গণনার পার্থক্য','stock_adjustment',1,0,1,1,'2026-08-04 07:23:54','2026-08-04 07:23:54',NULL),(6,3,'LOST','Lost or stolen','হারানো বা চুরি','stock_adjustment',0,1,1,1,'2026-08-04 07:23:54','2026-08-04 07:23:54',NULL),(7,3,'MISTAKE','Entry mistake','এন্ট্রির ভুল','cancellation',1,0,1,1,'2026-08-04 07:23:54','2026-08-04 07:23:54',NULL),(8,1,'DAMAGE','Damaged goods','ক্ষতিগ্রস্ত পণ্য','sales_return',0,0,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(9,1,'EXPIRED','Expired','মেয়াদোত্তীর্ণ','sales_return',0,0,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(10,1,'WRONG','Wrong item delivered','ভুল পণ্য দেওয়া হয়েছে','sales_return',1,0,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(11,1,'UNSOLD','Not sold','বিক্রি হয়নি','sales_return',1,0,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(12,1,'COUNT','Counting difference','গণনার পার্থক্য','stock_adjustment',1,0,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(13,1,'LOST','Lost or stolen','হারানো বা চুরি','stock_adjustment',0,1,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(14,1,'MISTAKE','Entry mistake','এন্ট্রির ভুল','cancellation',1,0,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(15,2,'DAMAGE','Damaged goods','ক্ষতিগ্রস্ত পণ্য','sales_return',0,0,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL),(16,2,'EXPIRED','Expired','মেয়াদোত্তীর্ণ','sales_return',0,0,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL),(17,2,'WRONG','Wrong item delivered','ভুল পণ্য দেওয়া হয়েছে','sales_return',1,0,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL),(18,2,'UNSOLD','Not sold','বিক্রি হয়নি','sales_return',1,0,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL),(19,2,'COUNT','Counting difference','গণনার পার্থক্য','stock_adjustment',1,0,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL),(20,2,'LOST','Lost or stolen','হারানো বা চুরি','stock_adjustment',0,1,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL),(21,2,'MISTAKE','Entry mistake','এন্ট্রির ভুল','cancellation',1,0,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL);
/*!40000 ALTER TABLE `mdm_reason_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdm_taxes`
--

DROP TABLE IF EXISTS `mdm_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mdm_taxes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `code` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_bn` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate` decimal(8,4) NOT NULL DEFAULT '0.0000',
  `kind` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'vat',
  `is_inclusive` tinyint(1) NOT NULL DEFAULT '0',
  `account_id` bigint unsigned DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdm_taxes_company_id_code_unique` (`company_id`,`code`),
  KEY `mdm_taxes_account_id_foreign` (`account_id`),
  KEY `mdm_taxes_created_by_foreign` (`created_by`),
  CONSTRAINT `mdm_taxes_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `mdm_taxes_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mdm_taxes_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdm_taxes`
--

LOCK TABLES `mdm_taxes` WRITE;
/*!40000 ALTER TABLE `mdm_taxes` DISABLE KEYS */;
INSERT INTO `mdm_taxes` VALUES (1,3,'VAT15','VAT 15%','ভ্যাট ১৫%',15.0000,'vat',0,NULL,1,1,1,'2026-08-04 07:23:53','2026-08-04 07:23:54',NULL),(2,3,'VAT75','VAT 7.5%','ভ্যাট ৭.৫%',7.5000,'vat',0,NULL,0,1,1,'2026-08-04 07:23:54','2026-08-04 07:23:54',NULL),(3,3,'VAT5','VAT 5%','ভ্যাট ৫%',5.0000,'vat',0,NULL,0,1,1,'2026-08-04 07:23:54','2026-08-04 07:23:54',NULL),(4,3,'NIL','No VAT','ভ্যাট নেই',0.0000,'vat',0,NULL,0,1,1,'2026-08-04 07:23:54','2026-08-04 07:23:54',NULL),(5,1,'VAT15','VAT 15%','ভ্যাট ১৫%',15.0000,'vat',0,NULL,1,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(6,1,'VAT75','VAT 7.5%','ভ্যাট ৭.৫%',7.5000,'vat',0,NULL,0,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(7,1,'VAT5','VAT 5%','ভ্যাট ৫%',5.0000,'vat',0,NULL,0,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(8,1,'NIL','No VAT','ভ্যাট নেই',0.0000,'vat',0,NULL,0,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(9,2,'VAT15','VAT 15%','ভ্যাট ১৫%',15.0000,'vat',0,NULL,1,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL),(10,2,'VAT75','VAT 7.5%','ভ্যাট ৭.৫%',7.5000,'vat',0,NULL,0,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL),(11,2,'VAT5','VAT 5%','ভ্যাট ৫%',5.0000,'vat',0,NULL,0,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL),(12,2,'NIL','No VAT','ভ্যাট নেই',0.0000,'vat',0,NULL,0,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL);
/*!40000 ALTER TABLE `mdm_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdm_units`
--

DROP TABLE IF EXISTS `mdm_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mdm_units` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `code` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_bn` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_unit_id` bigint unsigned DEFAULT NULL,
  `factor` decimal(18,6) NOT NULL DEFAULT '1.000000',
  `allows_fraction` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdm_units_company_id_code_unique` (`company_id`,`code`),
  KEY `mdm_units_base_unit_id_foreign` (`base_unit_id`),
  KEY `mdm_units_created_by_foreign` (`created_by`),
  CONSTRAINT `mdm_units_base_unit_id_foreign` FOREIGN KEY (`base_unit_id`) REFERENCES `mdm_units` (`id`) ON DELETE SET NULL,
  CONSTRAINT `mdm_units_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mdm_units_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdm_units`
--

LOCK TABLES `mdm_units` WRITE;
/*!40000 ALTER TABLE `mdm_units` DISABLE KEYS */;
INSERT INTO `mdm_units` VALUES (1,3,'PCS','Piece','পিস',NULL,1.000000,0,1,1,'2026-08-04 07:23:03','2026-08-04 07:23:03',NULL),(2,3,'DOZ','Dozen','ডজন',NULL,12.000000,0,1,1,'2026-08-04 07:23:03','2026-08-04 07:23:03',NULL),(3,3,'CTN','Carton','কার্টন',NULL,1.000000,0,1,1,'2026-08-04 07:23:03','2026-08-04 07:23:03',NULL),(4,3,'KG','Kilogram','কেজি',NULL,1.000000,1,1,1,'2026-08-04 07:23:03','2026-08-04 07:23:03',NULL),(5,3,'LTR','Litre','লিটার',NULL,1.000000,1,1,1,'2026-08-04 07:23:03','2026-08-04 07:23:03',NULL),(6,3,'BAG','Bag','বস্তা',NULL,1.000000,0,1,1,'2026-08-04 07:23:03','2026-08-04 07:23:03',NULL),(7,1,'PCS','Piece','পিস',NULL,1.000000,0,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(8,1,'DOZ','Dozen','ডজন',NULL,12.000000,0,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(9,1,'CTN','Carton','কার্টন',NULL,1.000000,0,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(10,1,'KG','Kilogram','কেজি',NULL,1.000000,1,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(11,1,'LTR','Litre','লিটার',NULL,1.000000,1,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(12,1,'BAG','Bag','বস্তা',NULL,1.000000,0,1,1,'2026-08-04 07:24:33','2026-08-04 07:24:33',NULL),(13,2,'PCS','Piece','পিস',NULL,1.000000,0,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL),(14,2,'DOZ','Dozen','ডজন',NULL,12.000000,0,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL),(15,2,'CTN','Carton','কার্টন',NULL,1.000000,0,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL),(16,2,'KG','Kilogram','কেজি',NULL,1.000000,1,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL),(17,2,'LTR','Litre','লিটার',NULL,1.000000,1,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL),(18,2,'BAG','Bag','বস্তা',NULL,1.000000,0,1,1,'2026-08-04 07:24:34','2026-08-04 07:24:34',NULL);
/*!40000 ALTER TABLE `mdm_units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_08_03_214923_create_activity_log_table',1),(5,'2026_08_03_214923_create_permission_tables',1),(6,'2026_08_03_214924_add_event_column_to_activity_log_table',1),(7,'2026_08_03_214925_add_batch_uuid_column_to_activity_log_table',1),(8,'2026_08_04_100000_create_companies_and_branches',1),(9,'2026_08_04_100100_create_company_user_and_settings',1),(10,'2026_08_04_100200_create_number_series',1),(11,'2026_08_04_100300_create_ledger_and_stock',1),(12,'2026_08_04_100400_create_approvals_and_attachments',1),(13,'2026_08_04_110000_add_accent_to_users',1),(14,'2026_08_04_120000_create_customers',2),(15,'2026_08_04_140000_add_avatar_path_to_users',2),(16,'2026_08_04_160000_create_accounts',3),(17,'2026_08_04_170000_create_cash_tills',4),(18,'2026_08_04_180000_create_vouchers',5),(19,'2026_08_04_190000_create_money_transfers_and_cash_counts',6),(20,'2026_08_04_200000_create_master_data',7),(21,'2026_08_04_210000_customers_use_party_types',8),(22,'2026_08_04_220000_create_suppliers',9);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',1),(2,'App\\Models\\User',2),(3,'App\\Models\\User',3);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `money_transfers`
--

DROP TABLE IF EXISTS `money_transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `money_transfers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `branch_id` bigint unsigned DEFAULT NULL,
  `financial_year_id` bigint unsigned NOT NULL,
  `document_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trx_date` date NOT NULL,
  `from_till_id` bigint unsigned DEFAULT NULL,
  `to_till_id` bigint unsigned DEFAULT NULL,
  `to_account_id` bigint unsigned DEFAULT NULL,
  `given_by` bigint unsigned DEFAULT NULL,
  `received_by` bigint unsigned DEFAULT NULL,
  `amount` decimal(18,4) NOT NULL,
  `narration` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `confirmed_at` timestamp NULL DEFAULT NULL,
  `confirmed_by` bigint unsigned DEFAULT NULL,
  `cancelled_by` bigint unsigned DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `cancel_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `money_transfers_company_id_document_no_unique` (`company_id`,`document_no`),
  KEY `money_transfers_branch_id_foreign` (`branch_id`),
  KEY `money_transfers_financial_year_id_foreign` (`financial_year_id`),
  KEY `money_transfers_from_till_id_foreign` (`from_till_id`),
  KEY `money_transfers_to_till_id_foreign` (`to_till_id`),
  KEY `money_transfers_to_account_id_foreign` (`to_account_id`),
  KEY `money_transfers_given_by_foreign` (`given_by`),
  KEY `money_transfers_received_by_foreign` (`received_by`),
  KEY `money_transfers_confirmed_by_foreign` (`confirmed_by`),
  KEY `money_transfers_cancelled_by_foreign` (`cancelled_by`),
  KEY `money_transfers_created_by_foreign` (`created_by`),
  KEY `money_transfers_company_id_trx_date_index` (`company_id`,`trx_date`),
  KEY `money_transfers_company_id_status_index` (`company_id`,`status`),
  CONSTRAINT `money_transfers_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `money_transfers_cancelled_by_foreign` FOREIGN KEY (`cancelled_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `money_transfers_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `money_transfers_confirmed_by_foreign` FOREIGN KEY (`confirmed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `money_transfers_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `money_transfers_financial_year_id_foreign` FOREIGN KEY (`financial_year_id`) REFERENCES `financial_years` (`id`) ON DELETE CASCADE,
  CONSTRAINT `money_transfers_from_till_id_foreign` FOREIGN KEY (`from_till_id`) REFERENCES `cash_tills` (`id`) ON DELETE SET NULL,
  CONSTRAINT `money_transfers_given_by_foreign` FOREIGN KEY (`given_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `money_transfers_received_by_foreign` FOREIGN KEY (`received_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `money_transfers_to_account_id_foreign` FOREIGN KEY (`to_account_id`) REFERENCES `accounts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `money_transfers_to_till_id_foreign` FOREIGN KEY (`to_till_id`) REFERENCES `cash_tills` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `money_transfers`
--

LOCK TABLES `money_transfers` WRITE;
/*!40000 ALTER TABLE `money_transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `money_transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `number_series`
--

DROP TABLE IF EXISTS `number_series`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `number_series` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `branch_id` bigint unsigned DEFAULT NULL,
  `financial_year_id` bigint unsigned DEFAULT NULL,
  `module` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `doc_type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prefix` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `suffix` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `format` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '{PREFIX}-{SEQ}',
  `padding` int unsigned NOT NULL DEFAULT '4',
  `next_number` bigint unsigned NOT NULL DEFAULT '1',
  `start_number` bigint unsigned NOT NULL DEFAULT '1',
  `reset_yearly` tinyint(1) NOT NULL DEFAULT '1',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `number_series_scope_unique` (`company_id`,`branch_id`,`doc_type`,`financial_year_id`),
  KEY `number_series_branch_id_foreign` (`branch_id`),
  KEY `number_series_financial_year_id_foreign` (`financial_year_id`),
  KEY `number_series_company_id_module_index` (`company_id`,`module`),
  CONSTRAINT `number_series_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `number_series_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `number_series_financial_year_id_foreign` FOREIGN KEY (`financial_year_id`) REFERENCES `financial_years` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `number_series`
--

LOCK TABLES `number_series` WRITE;
/*!40000 ALTER TABLE `number_series` DISABLE KEYS */;
INSERT INTO `number_series` VALUES (1,1,NULL,1,'sales','SI','INV','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 01:13:06','2026-08-04 01:13:06'),(2,1,NULL,1,'sales','SR','SRT','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 01:13:06','2026-08-04 01:13:06'),(3,1,NULL,1,'purchase','PI','PUR','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 01:13:06','2026-08-04 01:13:06'),(4,1,NULL,1,'accounts','RV','RCV','','{PREFIX}-{FY}-{SEQ}',4,5,1,1,1,'2026-08-04 01:13:06','2026-08-04 05:27:26'),(5,1,NULL,1,'accounts','PV','PAY','','{PREFIX}-{FY}-{SEQ}',4,5,1,1,1,'2026-08-04 01:13:06','2026-08-04 05:27:26'),(6,1,NULL,1,'accounts','JV','JRN','','{PREFIX}-{FY}-{SEQ}',4,3,1,1,1,'2026-08-04 01:13:06','2026-08-04 05:27:27'),(7,1,NULL,1,'accounts','CV','CON','','{PREFIX}-{FY}-{SEQ}',4,3,1,1,1,'2026-08-04 01:13:06','2026-08-04 05:27:26'),(8,1,NULL,1,'accounts','MT','TRF','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 01:13:06','2026-08-04 01:13:06'),(9,1,NULL,1,'accounts','CC','CNT','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 01:13:06','2026-08-04 01:13:06'),(10,1,NULL,1,'customer','CUS','CUS','','{PREFIX}-{FY}-{SEQ}',4,6,1,1,1,'2026-08-04 01:13:06','2026-08-04 03:53:46'),(11,2,NULL,2,'sales','SI','INV','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 01:13:06','2026-08-04 01:13:06'),(12,2,NULL,2,'sales','SR','SRT','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 01:13:06','2026-08-04 01:13:06'),(13,2,NULL,2,'purchase','PI','PUR','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 01:13:06','2026-08-04 01:13:06'),(14,2,NULL,2,'accounts','RV','RCV','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 01:13:06','2026-08-04 01:13:06'),(15,2,NULL,2,'accounts','PV','PAY','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 01:13:06','2026-08-04 01:13:06'),(16,2,NULL,2,'accounts','JV','JRN','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 01:13:06','2026-08-04 01:13:06'),(17,2,NULL,2,'accounts','CV','CON','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 01:13:06','2026-08-04 01:13:06'),(18,2,NULL,2,'accounts','MT','TRF','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 01:13:06','2026-08-04 01:13:06'),(19,2,NULL,2,'accounts','CC','CNT','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 01:13:06','2026-08-04 01:13:06'),(20,2,NULL,2,'customer','CUS','CUS','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 01:13:06','2026-08-04 01:13:06'),(21,1,NULL,1,'accounts','EV','EXP','','{PREFIX}-{FY}-{SEQ}',4,4,1,1,1,'2026-08-04 05:25:05','2026-08-04 05:27:26'),(22,2,NULL,2,'accounts','EV','EXP','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 05:25:05','2026-08-04 05:25:05'),(23,3,NULL,3,'accounts','RV','RCV','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02'),(24,3,NULL,3,'accounts','PV','PAY','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02'),(25,3,NULL,3,'accounts','EV','EXP','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02'),(26,3,NULL,3,'accounts','JV','JRN','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02'),(27,3,NULL,3,'accounts','CV','CON','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02'),(28,3,NULL,3,'accounts','MT','TRF','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02'),(29,3,NULL,3,'accounts','CC','CNT','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02'),(30,3,NULL,3,'customer','CUS','CUS','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 07:23:02','2026-08-04 07:23:02'),(31,1,NULL,1,'supplier','SUP','SUP','','{PREFIX}-{FY}-{SEQ}',4,5,1,1,1,'2026-08-04 08:48:52','2026-08-04 08:48:52'),(32,2,NULL,2,'supplier','SUP','SUP','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 08:48:52','2026-08-04 08:48:52'),(33,3,NULL,3,'supplier','SUP','SUP','','{PREFIX}-{FY}-{SEQ}',4,1,1,1,1,'2026-08-04 08:48:52','2026-08-04 08:48:52');
/*!40000 ALTER TABLE `number_series` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'accounts.view','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(2,'accounts.manage','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(3,'accounts.coa.view','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(4,'accounts.coa.manage','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(5,'accounts.voucher.create','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(6,'accounts.voucher.update','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(7,'accounts.voucher.delete','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(8,'accounts.voucher.approve','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(9,'accounts.voucher.backdate','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(10,'accounts.report','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(11,'accounts.report.final','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(12,'accounts.till.view','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(13,'accounts.till.manage','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(14,'accounts.transfer.create','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(15,'accounts.transfer.confirm','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(16,'accounts.count.create','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(17,'accounts.count.approve','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(18,'customer.view','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(19,'customer.create','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(20,'customer.update','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(21,'customer.delete','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(22,'customer.report','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(23,'customer.manage','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(24,'customer.credit_limit.override','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(25,'system_admin.company.manage','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(26,'system_admin.user.manage','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(27,'system_admin.role.manage','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(28,'system_admin.settings.manage','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(29,'system_admin.audit.view','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(30,'system_admin.backup.manage','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(31,'master_data.view','web','2026-08-04 07:23:02','2026-08-04 07:23:02'),(32,'master_data.manage','web','2026-08-04 07:23:02','2026-08-04 07:23:02'),(33,'supplier.view','web','2026-08-04 08:47:42','2026-08-04 08:47:42'),(34,'supplier.create','web','2026-08-04 08:47:42','2026-08-04 08:47:42'),(35,'supplier.update','web','2026-08-04 08:47:42','2026-08-04 08:47:42'),(36,'supplier.delete','web','2026-08-04 08:47:42','2026-08-04 08:47:42'),(37,'supplier.report','web','2026-08-04 08:47:42','2026-08-04 08:47:42'),(38,'supplier.manage','web','2026-08-04 08:47:42','2026-08-04 08:47:42');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(11,1),(12,1),(13,1),(14,1),(15,1),(16,1),(17,1),(18,1),(19,1),(20,1),(21,1),(22,1),(23,1),(24,1),(25,1),(26,1),(27,1),(28,1),(29,1),(30,1),(31,1),(32,1),(33,1),(34,1),(35,1),(36,1),(37,1),(38,1),(1,2),(2,2),(3,2),(4,2),(5,2),(6,2),(7,2),(8,2),(9,2),(10,2),(11,2),(12,2),(13,2),(14,2),(15,2),(16,2),(17,2),(18,3),(19,3),(20,3),(21,3),(22,3),(23,3);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'owner','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(2,'accountant','web','2026-08-04 01:13:06','2026-08-04 01:13:06'),(3,'salesman','web','2026-08-04 01:13:06','2026-08-04 01:13:06');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('0Zz5DBisaI4Tq9ssy6HyXqjdmczynHxPdUbUn4sa',NULL,'127.0.0.1','curl/8.21.0','eyJfdG9rZW4iOiJNaDRGMTlzNDJTVWZGdHZIMEFkZnF2a01zRjZXZ25lcktCMDh2dVZPIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEyNy4wLjAuMTo4MTAwXC9sb2dpbiIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1785857313),('2BNQcPmm3KIHjCcVIttyMIUOgR9fkAp8pNteP0e8',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/151.0.7922.34 Safari/537.36','eyJfdG9rZW4iOiJJdHVaN0ltUUhaU2J5T0YzMTZmbDBTVTVGOXZjRFFDVDRoc2lHNThOIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEyNy4wLjAuMTo4MTAwXC9tYXN0ZXItZGF0YVwvbG9jYXRpb25zIiwicm91dGUiOiJtYXN0ZXJfZGF0YS5sb2NhdGlvbi5pbmRleCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjoxfQ==',1785851521),('8mhSGg6siCcIXmSwio3YDTTf5I9OLqmu8FfPzy9e',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/151.0.7922.34 Safari/537.36','eyJfdG9rZW4iOiJISklJUlE3eFRRVFhqT2FxZmVXYlhFUUNORGZUN2FadjVVWlo5aTR3IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEyNy4wLjAuMTo4MTAwXC9jdXN0b21lcnNcL2NyZWF0ZSIsInJvdXRlIjoiY3VzdG9tZXIuY3JlYXRlIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjF9',1785858002),('BdhDqqDSgmNsuyIvKfcacsFjDenCVXWxy6nYJIb6',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/151.0.7922.34 Safari/537.36','eyJfdG9rZW4iOiJMY0IwdkxDOVR3Wlc4QnlpYXVsQkduYVN1U1FYanpybExuMEp4UXdYIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEyNy4wLjAuMTo4MTAwXC9jdXN0b21lcnNcL2NyZWF0ZSIsInJvdXRlIjoiY3VzdG9tZXIuY3JlYXRlIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjF9',1785857912),('dNV8Z44xmdipGhRo1njwC1DCnnJww2ZnDq6SipvF',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','eyJfdG9rZW4iOiI5N3NZcjVUSTZiQU40U0pBNmtjUXdib2dUVjAxSDVPZVBDUzBoMG14IiwidXJsIjpbXSwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEyNy4wLjAuMTo4MTAwXC9tYXN0ZXItZGF0YVwvdGF4ZXMiLCJyb3V0ZSI6Im1hc3Rlcl9kYXRhLnRheC5pbmRleCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjoxfQ==',1785859743),('Eh4kK60Lzxmo4fqrpWT98RH6S9SKT47eNQPNHpPV',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/151.0.7922.34 Safari/537.36','eyJfdG9rZW4iOiJuWXlkcmI2TERxRHhndW5YSW1XV2d3VXNBVkZWN1lEc3pQYjA5TDNrIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEyNy4wLjAuMTo4MTAwXC9jdXN0b21lcnNcL2NyZWF0ZSIsInJvdXRlIjoiY3VzdG9tZXIuY3JlYXRlIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjF9',1785859301),('jZDaEcpT8013ag1Xs5G8LjjcGI684Pj84Z8LWP37',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/151.0.7922.34 Safari/537.36','eyJfdG9rZW4iOiIyczh2ZXdOSk9uajB3eVdEN1FkUXBPUmdlTDRvTTdIUllEMmpBTG04IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEyNy4wLjAuMTo4MTAwXC9jdXN0b21lcnNcL2NyZWF0ZSIsInJvdXRlIjoiY3VzdG9tZXIuY3JlYXRlIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjF9',1785857566),('kQE2IpR19vFVtfLkroXoseAyiz06hIKsPOo5k0vq',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/151.0.7922.34 Safari/537.36','eyJfdG9rZW4iOiI1SGNTdkpWbXIzS2paMUhERXRFcWNIbXNXSDZZcGVwemp6Vk1sTnBHIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEyNy4wLjAuMTo4MTAwXC9jdXN0b21lcnNcL2NyZWF0ZSIsInJvdXRlIjoiY3VzdG9tZXIuY3JlYXRlIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjF9',1785857412),('Q8PYrLDEu3z6HGcVhkfNANdA0cdU0Fi4nkIB8LqO',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/151.0.7922.34 Safari/537.36','eyJfdG9rZW4iOiJHdUoxU1pIUUhkb25ZSTdHZEl4bnJUYUpuN2k4akpjUjRPNkVtRWVxIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEyNy4wLjAuMTo4MTAwXC9jdXN0b21lcnNcL2NyZWF0ZSIsInJvdXRlIjoiY3VzdG9tZXIuY3JlYXRlIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjF9',1785858091),('RpKeSUlPK93X4HjVcppVuPZrFBvDBpLmeENcWByi',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/151.0.7922.34 Safari/537.36','eyJfdG9rZW4iOiJsRUUxNVBVRTZoSUJUcjVLRURraDB3YmNrTXJ0ZlJ4REtFWENLTWZyIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEyNy4wLjAuMTo4MTAwXC9jdXN0b21lcnNcL2NyZWF0ZSIsInJvdXRlIjoiY3VzdG9tZXIuY3JlYXRlIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjF9',1785857693),('TwPwDN4bS9rPRyjDXQShBRQn8DuGA9YG8y9GgjHm',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/151.0.7922.34 Safari/537.36','eyJfdG9rZW4iOiJsWWtmdlRTT1FJaWZHVm54YjVvWWt4a3Y4bGlrQ1NDWkdaOVZGWDlhIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEyNy4wLjAuMTo4MTAwXC9tYXN0ZXItZGF0YVwvbG9jYXRpb25zIiwicm91dGUiOiJtYXN0ZXJfZGF0YS5sb2NhdGlvbi5pbmRleCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjoxfQ==',1785851483),('xI2AdgPw8cAUzs7Nxosu4YOiz9PGBkr0X34rqP7s',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/151.0.7922.34 Safari/537.36','eyJfdG9rZW4iOiJ4OHJCS1A4V2ZkRkNFUUYySEk0SWlNNmNscXFPZHFsMVdwNERSWXdnIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEyNy4wLjAuMTo4MTAwXC9zdXBwbGllcnM/c29ydD1kcm9wJTIwdGFibGUiLCJyb3V0ZSI6InN1cHBsaWVyLmluZGV4In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjF9',1785859392),('zaZusAskf3DHNf3e3C4Oj0VWECyw840CTjpF7KH4',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/151.0.7922.34 Safari/537.36','eyJfdG9rZW4iOiJGYUhDVWhxMmhjRFdleEJPT2REa29EbThMTXdpaERKMm9MRTVvQm1jIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEyNy4wLjAuMTo4MTAwXC9zeXN0ZW1cL2NvbnRyb2wtcGFuZWwiLCJyb3V0ZSI6InN5c3RlbV9hZG1pbi5jb250cm9sLXBhbmVsIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjF9',1785852790);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned DEFAULT NULL,
  `module` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'string',
  `value` text COLLATE utf8mb4_unicode_ci,
  `group` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'general',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_company_id_key_unique` (`company_id`,`key`),
  KEY `settings_company_id_module_group_index` (`company_id`,`module`,`group`),
  CONSTRAINT `settings_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_movements`
--

DROP TABLE IF EXISTS `stock_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_movements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `branch_id` bigint unsigned DEFAULT NULL,
  `product_id` bigint unsigned NOT NULL,
  `warehouse_id` bigint unsigned NOT NULL,
  `trx_date` date NOT NULL,
  `qty` decimal(18,3) NOT NULL,
  `unit_cost` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `state` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'available',
  `is_free` tinyint(1) NOT NULL DEFAULT '0',
  `source_type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_id` bigint unsigned NOT NULL,
  `source_line_id` bigint unsigned DEFAULT NULL,
  `document_no` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_movements_branch_id_foreign` (`branch_id`),
  KEY `stock_movements_created_by_foreign` (`created_by`),
  KEY `stock_product_wh_date` (`company_id`,`product_id`,`warehouse_id`,`trx_date`),
  KEY `stock_company_date` (`company_id`,`trx_date`),
  KEY `stock_source` (`source_type`,`source_id`),
  CONSTRAINT `stock_movements_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stock_movements_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_movements_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_movements`
--

LOCK TABLES `stock_movements` WRITE;
/*!40000 ALTER TABLE `stock_movements` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `branch_id` bigint unsigned DEFAULT NULL,
  `code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_bn` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_en` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_bn` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_person` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_phone` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `party_type_id` bigint unsigned DEFAULT NULL,
  `payment_term_id` bigint unsigned DEFAULT NULL,
  `bin` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tin` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `credit_limit` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `credit_days` smallint unsigned NOT NULL DEFAULT '0',
  `opening_balance` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `opening_date` date DEFAULT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'confirmed',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `suppliers_company_id_code_unique` (`company_id`,`code`),
  KEY `suppliers_branch_id_foreign` (`branch_id`),
  KEY `suppliers_party_type_id_foreign` (`party_type_id`),
  KEY `suppliers_payment_term_id_foreign` (`payment_term_id`),
  KEY `suppliers_created_by_foreign` (`created_by`),
  KEY `suppliers_company_id_is_active_index` (`company_id`,`is_active`),
  KEY `suppliers_company_id_name_en_index` (`company_id`,`name_en`),
  CONSTRAINT `suppliers_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `suppliers_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `suppliers_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `suppliers_party_type_id_foreign` FOREIGN KEY (`party_type_id`) REFERENCES `mdm_party_types` (`id`) ON DELETE SET NULL,
  CONSTRAINT `suppliers_payment_term_id_foreign` FOREIGN KEY (`payment_term_id`) REFERENCES `mdm_payment_terms` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,1,NULL,'SUP-2026-2027-0001','Pran RFL Group','প্রাণ আরএফএল গ্রুপ','+8809610010010',NULL,'Mymensingh, Bangladesh','ময়মনসিংহ, বাংলাদেশ','Rezaul Karim','+8801711000001',10,8,'000123456-0101','123456789012',500000.0000,30,125000.0000,'2026-07-01','confirmed',1,NULL,'2026-08-04 08:48:52','2026-08-04 08:48:52',NULL),(2,1,NULL,'SUP-2026-2027-0002','Square Consumer Products','স্কয়ার কনজিউমার প্রোডাক্টস','+8809610020020',NULL,'Mymensingh, Bangladesh','ময়মনসিংহ, বাংলাদেশ','Nusrat Jahan','+8801711000002',10,8,'000223456-0202','223456789012',300000.0000,15,48500.0000,'2026-07-01','confirmed',1,NULL,'2026-08-04 08:48:52','2026-08-04 08:48:52',NULL),(3,1,NULL,'SUP-2026-2027-0003','Akij Food & Beverage','আকিজ ফুড অ্যান্ড বেভারেজ','+8809610030030',NULL,'Mymensingh, Bangladesh','ময়মনসিংহ, বাংলাদেশ','Mahbub Alam','+8801711000003',10,8,'000323456-0303','323456789012',250000.0000,21,0.0000,NULL,'confirmed',1,NULL,'2026-08-04 08:48:52','2026-08-04 08:48:52',NULL),(4,1,NULL,'SUP-2026-2027-0004','Mymensingh Packaging House','ময়মনসিংহ প্যাকেজিং হাউস','+8801711000004',NULL,'Mymensingh, Bangladesh','ময়মনসিংহ, বাংলাদেশ',NULL,NULL,10,NULL,NULL,NULL,0.0000,0,7200.0000,'2026-07-01','confirmed',1,NULL,'2026-08-04 08:48:52','2026-08-04 08:48:52',NULL);
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `current_company_id` bigint unsigned DEFAULT NULL,
  `current_branch_id` bigint unsigned DEFAULT NULL,
  `locale` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'bn',
  `theme` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'light',
  `accent` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'blue',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `last_login_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_current_company_id_foreign` (`current_company_id`),
  KEY `users_current_branch_id_foreign` (`current_branch_id`),
  CONSTRAINT `users_current_branch_id_foreign` FOREIGN KEY (`current_branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `users_current_company_id_foreign` FOREIGN KEY (`current_company_id`) REFERENCES `companies` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Al Amin Shuvo','owner@abos.test','avatars/1-3db728147b1ac6ba.jpg',NULL,'$2y$12$LAFaVMKlHfFOJuCxdUGTIe2JkRgumWs6bZk1KXcNUgANgDkioYyF2',1,1,'bn','light','blue',1,'2026-08-04 10:03:01','Vo2LsiKbRWYORITcQBIbccFyGXPRzgWFInEwRhRYQjjQk3NH4qF40ENnPD51','2026-08-04 01:13:06','2026-08-04 10:03:01',NULL),(2,'হিসাবরক্ষক','accounts@abos.test',NULL,NULL,'$2y$12$/wGkgwNYwnTgD1EN7HMEUOqwDYbRFv3nloYEeqpEoMCLdIZgcFxuG',1,1,'bn','light','blue',1,NULL,NULL,'2026-08-04 01:13:07','2026-08-04 01:13:07',NULL),(3,'বিক্রয়কর্মী','sales@abos.test',NULL,NULL,'$2y$12$fDqVs2UD4/KrdiNqYnU4.e/NIFJ3b6ooODYKdFe/OQcX8fXEfaidG',1,1,'bn','light','blue',1,NULL,NULL,'2026-08-04 01:13:07','2026-08-04 01:13:07',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voucher_lines`
--

DROP TABLE IF EXISTS `voucher_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `voucher_lines` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `voucher_id` bigint unsigned NOT NULL,
  `account_id` bigint unsigned NOT NULL,
  `party_type` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `party_id` bigint unsigned DEFAULT NULL,
  `debit` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `credit` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `narration` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `voucher_lines_account_id_foreign` (`account_id`),
  KEY `voucher_lines_voucher_id_sort_order_index` (`voucher_id`,`sort_order`),
  CONSTRAINT `voucher_lines_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `voucher_lines_voucher_id_foreign` FOREIGN KEY (`voucher_id`) REFERENCES `vouchers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voucher_lines`
--

LOCK TABLES `voucher_lines` WRITE;
/*!40000 ALTER TABLE `voucher_lines` DISABLE KEYS */;
INSERT INTO `voucher_lines` VALUES (21,11,104,NULL,NULL,5000.0000,0.0000,'করিম স্টোর থেকে আদায়',0,'2026-08-04 05:27:26','2026-08-04 05:27:26'),(22,11,5,NULL,NULL,0.0000,5000.0000,'করিম স্টোর থেকে আদায়',1,'2026-08-04 05:27:26','2026-08-04 05:27:26'),(23,12,17,NULL,NULL,3000.0000,0.0000,'সরবরাহকারীকে পরিশোধ',0,'2026-08-04 05:27:26','2026-08-04 05:27:26'),(24,12,104,NULL,NULL,0.0000,3000.0000,'সরবরাহকারীকে পরিশোধ',1,'2026-08-04 05:27:26','2026-08-04 05:27:26'),(25,13,37,NULL,NULL,8000.0000,0.0000,'আগস্টের দোকান ভাড়া',0,'2026-08-04 05:27:26','2026-08-04 05:27:26'),(26,13,104,NULL,NULL,0.0000,8000.0000,'আগস্টের দোকান ভাড়া',1,'2026-08-04 05:27:26','2026-08-04 05:27:26'),(27,14,106,NULL,NULL,4000.0000,0.0000,'ব্যাংকে জমা',0,'2026-08-04 05:27:26','2026-08-04 05:27:26'),(28,14,104,NULL,NULL,0.0000,4000.0000,'ব্যাংকে জমা',1,'2026-08-04 05:27:26','2026-08-04 05:27:26'),(29,15,47,NULL,NULL,4500.0000,0.0000,NULL,0,'2026-08-04 05:27:27','2026-08-04 05:27:27'),(30,15,14,NULL,NULL,0.0000,4500.0000,NULL,1,'2026-08-04 05:27:27','2026-08-04 05:27:27');
/*!40000 ALTER TABLE `voucher_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vouchers`
--

DROP TABLE IF EXISTS `vouchers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vouchers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `branch_id` bigint unsigned DEFAULT NULL,
  `financial_year_id` bigint unsigned NOT NULL,
  `type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `document_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trx_date` date NOT NULL,
  `party_type` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `party_id` bigint unsigned DEFAULT NULL,
  `amount` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `narration` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instrument` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instrument_no` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instrument_date` date DEFAULT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `approved_by` bigint unsigned DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `cancelled_by` bigint unsigned DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `cancel_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vouchers_company_id_document_no_unique` (`company_id`,`document_no`),
  KEY `vouchers_branch_id_foreign` (`branch_id`),
  KEY `vouchers_financial_year_id_foreign` (`financial_year_id`),
  KEY `vouchers_approved_by_foreign` (`approved_by`),
  KEY `vouchers_cancelled_by_foreign` (`cancelled_by`),
  KEY `vouchers_created_by_foreign` (`created_by`),
  KEY `vouchers_company_id_type_trx_date_index` (`company_id`,`type`,`trx_date`),
  KEY `vouchers_company_id_party_type_party_id_index` (`company_id`,`party_type`,`party_id`),
  KEY `vouchers_company_id_status_index` (`company_id`,`status`),
  CONSTRAINT `vouchers_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `vouchers_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `vouchers_cancelled_by_foreign` FOREIGN KEY (`cancelled_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `vouchers_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `vouchers_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `vouchers_financial_year_id_foreign` FOREIGN KEY (`financial_year_id`) REFERENCES `financial_years` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vouchers`
--

LOCK TABLES `vouchers` WRITE;
/*!40000 ALTER TABLE `vouchers` DISABLE KEYS */;
INSERT INTO `vouchers` VALUES (11,1,1,1,'receipt','RCV-2026-2027-0004','2026-08-04','customer',1,5000.0000,'করিম স্টোর থেকে আদায়','cash',NULL,NULL,'confirmed',1,'2026-08-04 05:27:26',NULL,NULL,NULL,1,'2026-08-04 05:27:26','2026-08-04 05:27:26',NULL),(12,1,1,1,'payment','PAY-2026-2027-0004','2026-08-04',NULL,NULL,3000.0000,'সরবরাহকারীকে পরিশোধ','cash',NULL,NULL,'confirmed',1,'2026-08-04 05:27:26',NULL,NULL,NULL,1,'2026-08-04 05:27:26','2026-08-04 05:27:26',NULL),(13,1,1,1,'expense','EXP-2026-2027-0003','2026-08-04',NULL,NULL,8000.0000,'আগস্টের দোকান ভাড়া','cash',NULL,NULL,'confirmed',1,'2026-08-04 05:27:26',NULL,NULL,NULL,1,'2026-08-04 05:27:26','2026-08-04 05:27:26',NULL),(14,1,1,1,'contra','CON-2026-2027-0002','2026-08-04',NULL,NULL,4000.0000,'ব্যাংকে জমা','transfer',NULL,NULL,'confirmed',1,'2026-08-04 05:27:27',NULL,NULL,NULL,1,'2026-08-04 05:27:26','2026-08-04 05:27:27',NULL),(15,1,1,1,'journal','JRN-2026-2027-0002','2026-08-04',NULL,NULL,4500.0000,'আগস্টের অবচয়',NULL,NULL,NULL,'confirmed',1,'2026-08-04 05:27:27',NULL,NULL,NULL,1,'2026-08-04 05:27:27','2026-08-04 05:27:27',NULL);
/*!40000 ALTER TABLE `vouchers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'abos'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-04 22:10:45
